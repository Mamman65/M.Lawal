import { users, questions, solutions, studySessions, formulas, achievements, flashcards, quizzes, quizAttempts, studyPlans,
         type User, type InsertUser, type Question, type InsertQuestion,
         type Solution, type InsertSolution, type StudySession, type InsertStudySession,
         type Formula, type InsertFormula, type Achievement, type InsertAchievement,
         type Flashcard, type InsertFlashcard, type Quiz, type InsertQuiz,
         type QuizAttempt, type InsertQuizAttempt, type StudyPlan, type InsertStudyPlan } from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Question operations
  getQuestion(id: number): Promise<Question | undefined>;
  getQuestionsByUser(userId: number): Promise<Question[]>;
  createQuestion(question: InsertQuestion & { userId: number }): Promise<Question>;
  
  // Solution operations
  getSolution(id: number): Promise<Solution | undefined>;
  getSolutionByQuestion(questionId: number): Promise<Solution | undefined>;
  createSolution(solution: InsertSolution): Promise<Solution>;
  
  // Study session operations
  getStudySession(id: number): Promise<StudySession | undefined>;
  getStudySessionsByUser(userId: number): Promise<StudySession[]>;
  createStudySession(session: InsertStudySession & { userId: number }): Promise<StudySession>;
  getUserStats(userId: number): Promise<{
    totalQuestions: number;
    totalStudyTime: number;
    averageAccuracy: number;
    streak: number;
  }>;
  
  // Formula operations
  getFormula(id: number): Promise<Formula | undefined>;
  getFormulasBySubject(subject: string): Promise<Formula[]>;
  getAllFormulas(): Promise<Formula[]>;
  createFormula(formula: InsertFormula): Promise<Formula>;
  
  // Achievement operations
  getAchievement(id: number): Promise<Achievement | undefined>;
  getAchievementsByUser(userId: number): Promise<Achievement[]>;
  createAchievement(achievement: InsertAchievement & { userId: number }): Promise<Achievement>;
  
  // Flashcard operations
  getFlashcard(id: number): Promise<Flashcard | undefined>;
  getFlashcardsByUser(userId: number): Promise<Flashcard[]>;
  getFlashcardsBySubject(userId: number, subject: string): Promise<Flashcard[]>;
  createFlashcard(flashcard: InsertFlashcard & { userId: number }): Promise<Flashcard>;
  updateFlashcard(id: number, updates: Partial<Flashcard>): Promise<Flashcard>;
  deleteFlashcard(id: number): Promise<boolean>;
  
  // Quiz operations
  getQuiz(id: number): Promise<Quiz | undefined>;
  getQuizzesByUser(userId: number): Promise<Quiz[]>;
  getQuizzesBySubject(subject: string): Promise<Quiz[]>;
  createQuiz(quiz: InsertQuiz & { userId: number }): Promise<Quiz>;
  
  // Quiz attempt operations
  getQuizAttempt(id: number): Promise<QuizAttempt | undefined>;
  getQuizAttemptsByUser(userId: number): Promise<QuizAttempt[]>;
  getQuizAttemptsByQuiz(quizId: number): Promise<QuizAttempt[]>;
  createQuizAttempt(attempt: InsertQuizAttempt & { userId: number }): Promise<QuizAttempt>;
  
  // Study plan operations
  getStudyPlan(id: number): Promise<StudyPlan | undefined>;
  getStudyPlansByUser(userId: number): Promise<StudyPlan[]>;
  createStudyPlan(plan: InsertStudyPlan & { userId: number }): Promise<StudyPlan>;
  updateStudyPlan(id: number, updates: Partial<StudyPlan>): Promise<StudyPlan>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private questions: Map<number, Question>;
  private solutions: Map<number, Solution>;
  private studySessions: Map<number, StudySession>;
  private formulas: Map<number, Formula>;
  private achievements: Map<number, Achievement>;
  private flashcards: Map<number, Flashcard>;
  private quizzes: Map<number, Quiz>;
  private quizAttempts: Map<number, QuizAttempt>;
  private studyPlans: Map<number, StudyPlan>;
  private currentId: number;

  constructor() {
    this.users = new Map();
    this.questions = new Map();
    this.solutions = new Map();
    this.studySessions = new Map();
    this.formulas = new Map();
    this.achievements = new Map();
    this.flashcards = new Map();
    this.quizzes = new Map();
    this.quizAttempts = new Map();
    this.studyPlans = new Map();
    this.currentId = 1;
    
    // Initialize with some default formulas
    this.initializeFormulas();
  }

  private initializeFormulas() {
    const defaultFormulas = [
      {
        name: "Quadratic Formula",
        formula: "x = (-b ± √(b² - 4ac)) / 2a",
        subject: "Mathematics",
        description: "Solves quadratic equations of the form ax² + bx + c = 0",
        examples: [
          { equation: "x² - 5x + 6 = 0", solution: "x = 2 or x = 3" }
        ],
        difficulty: "intermediate"
      },
      {
        name: "Newton's Second Law",
        formula: "F = ma",
        subject: "Physics",
        description: "The acceleration of an object is directly proportional to the net force acting on it",
        examples: [
          { problem: "Force = 10N, mass = 2kg", solution: "acceleration = 5 m/s²" }
        ],
        difficulty: "basic"
      },
      {
        name: "Ohm's Law",
        formula: "V = IR",
        subject: "Physics",
        description: "The voltage across a conductor is proportional to the current flowing through it",
        examples: [
          { problem: "Current = 2A, Resistance = 5Ω", solution: "Voltage = 10V" }
        ],
        difficulty: "basic"
      }
    ];

    defaultFormulas.forEach(formula => {
      const id = this.currentId++;
      this.formulas.set(id, { ...formula, id });
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt: new Date() 
    };
    this.users.set(id, user);
    return user;
  }

  async getQuestion(id: number): Promise<Question | undefined> {
    return this.questions.get(id);
  }

  async getQuestionsByUser(userId: number): Promise<Question[]> {
    return Array.from(this.questions.values()).filter(q => q.userId === userId);
  }

  async createQuestion(question: InsertQuestion & { userId: number }): Promise<Question> {
    const id = this.currentId++;
    const newQuestion: Question = {
      ...question,
      id,
      createdAt: new Date()
    };
    this.questions.set(id, newQuestion);
    return newQuestion;
  }

  async getSolution(id: number): Promise<Solution | undefined> {
    return this.solutions.get(id);
  }

  async getSolutionByQuestion(questionId: number): Promise<Solution | undefined> {
    return Array.from(this.solutions.values()).find(s => s.questionId === questionId);
  }

  async createSolution(solution: InsertSolution): Promise<Solution> {
    const id = this.currentId++;
    const newSolution: Solution = {
      ...solution,
      id,
      createdAt: new Date()
    };
    this.solutions.set(id, newSolution);
    return newSolution;
  }

  async getStudySession(id: number): Promise<StudySession | undefined> {
    return this.studySessions.get(id);
  }

  async getStudySessionsByUser(userId: number): Promise<StudySession[]> {
    return Array.from(this.studySessions.values()).filter(s => s.userId === userId);
  }

  async createStudySession(session: InsertStudySession & { userId: number }): Promise<StudySession> {
    const id = this.currentId++;
    const newSession: StudySession = {
      ...session,
      id,
      createdAt: new Date()
    };
    this.studySessions.set(id, newSession);
    return newSession;
  }

  async getUserStats(userId: number): Promise<{
    totalQuestions: number;
    totalStudyTime: number;
    averageAccuracy: number;
    streak: number;
  }> {
    const userQuestions = await this.getQuestionsByUser(userId);
    const userSessions = await this.getStudySessionsByUser(userId);
    
    const totalQuestions = userQuestions.length;
    const totalStudyTime = userSessions.reduce((sum, session) => sum + (session.duration || 0), 0);
    const averageAccuracy = userSessions.length > 0 
      ? userSessions.reduce((sum, session) => sum + (session.accuracy || 0), 0) / userSessions.length
      : 0;
    
    // Calculate streak (simplified - consecutive days with sessions)
    const today = new Date();
    let streak = 0;
    for (let i = 0; i < 30; i++) {
      const checkDate = new Date(today);
      checkDate.setDate(today.getDate() - i);
      const hasSession = userSessions.some(session => {
        const sessionDate = new Date(session.createdAt!);
        return sessionDate.toDateString() === checkDate.toDateString();
      });
      if (hasSession) {
        streak++;
      } else if (i > 0) {
        break;
      }
    }

    return {
      totalQuestions,
      totalStudyTime,
      averageAccuracy: Math.round(averageAccuracy),
      streak
    };
  }

  async getFormula(id: number): Promise<Formula | undefined> {
    return this.formulas.get(id);
  }

  async getFormulasBySubject(subject: string): Promise<Formula[]> {
    return Array.from(this.formulas.values()).filter(f => f.subject === subject);
  }

  async getAllFormulas(): Promise<Formula[]> {
    return Array.from(this.formulas.values());
  }

  async createFormula(formula: InsertFormula): Promise<Formula> {
    const id = this.currentId++;
    const newFormula: Formula = { ...formula, id };
    this.formulas.set(id, newFormula);
    return newFormula;
  }

  async getAchievement(id: number): Promise<Achievement | undefined> {
    return this.achievements.get(id);
  }

  async getAchievementsByUser(userId: number): Promise<Achievement[]> {
    return Array.from(this.achievements.values()).filter(a => a.userId === userId);
  }

  async createAchievement(achievement: InsertAchievement & { userId: number }): Promise<Achievement> {
    const id = this.currentId++;
    const newAchievement: Achievement = {
      ...achievement,
      id,
      earnedAt: new Date()
    };
    this.achievements.set(id, newAchievement);
    return newAchievement;
  }

  // Flashcard operations
  async getFlashcard(id: number): Promise<Flashcard | undefined> {
    return this.flashcards.get(id);
  }

  async getFlashcardsByUser(userId: number): Promise<Flashcard[]> {
    return Array.from(this.flashcards.values()).filter(f => f.userId === userId);
  }

  async getFlashcardsBySubject(userId: number, subject: string): Promise<Flashcard[]> {
    return Array.from(this.flashcards.values()).filter(f => f.userId === userId && f.subject === subject);
  }

  async createFlashcard(flashcard: InsertFlashcard & { userId: number }): Promise<Flashcard> {
    const id = this.currentId++;
    const newFlashcard: Flashcard = {
      ...flashcard,
      id,
      timesReviewed: 0,
      lastReviewed: null,
      createdAt: new Date()
    };
    this.flashcards.set(id, newFlashcard);
    return newFlashcard;
  }

  async updateFlashcard(id: number, updates: Partial<Flashcard>): Promise<Flashcard> {
    const flashcard = this.flashcards.get(id);
    if (!flashcard) throw new Error('Flashcard not found');
    
    const updated = { ...flashcard, ...updates };
    this.flashcards.set(id, updated);
    return updated;
  }

  async deleteFlashcard(id: number): Promise<boolean> {
    return this.flashcards.delete(id);
  }

  // Quiz operations
  async getQuiz(id: number): Promise<Quiz | undefined> {
    return this.quizzes.get(id);
  }

  async getQuizzesByUser(userId: number): Promise<Quiz[]> {
    return Array.from(this.quizzes.values()).filter(q => q.userId === userId);
  }

  async getQuizzesBySubject(subject: string): Promise<Quiz[]> {
    return Array.from(this.quizzes.values()).filter(q => q.subject === subject);
  }

  async createQuiz(quiz: InsertQuiz & { userId: number }): Promise<Quiz> {
    const id = this.currentId++;
    const newQuiz: Quiz = {
      ...quiz,
      id,
      createdAt: new Date()
    };
    this.quizzes.set(id, newQuiz);
    return newQuiz;
  }

  // Quiz attempt operations
  async getQuizAttempt(id: number): Promise<QuizAttempt | undefined> {
    return this.quizAttempts.get(id);
  }

  async getQuizAttemptsByUser(userId: number): Promise<QuizAttempt[]> {
    return Array.from(this.quizAttempts.values()).filter(a => a.userId === userId);
  }

  async getQuizAttemptsByQuiz(quizId: number): Promise<QuizAttempt[]> {
    return Array.from(this.quizAttempts.values()).filter(a => a.quizId === quizId);
  }

  async createQuizAttempt(attempt: InsertQuizAttempt & { userId: number }): Promise<QuizAttempt> {
    const id = this.currentId++;
    const newAttempt: QuizAttempt = {
      ...attempt,
      id,
      completedAt: new Date()
    };
    this.quizAttempts.set(id, newAttempt);
    return newAttempt;
  }

  // Study plan operations
  async getStudyPlan(id: number): Promise<StudyPlan | undefined> {
    return this.studyPlans.get(id);
  }

  async getStudyPlansByUser(userId: number): Promise<StudyPlan[]> {
    return Array.from(this.studyPlans.values()).filter(p => p.userId === userId);
  }

  async createStudyPlan(plan: InsertStudyPlan & { userId: number }): Promise<StudyPlan> {
    const id = this.currentId++;
    const newPlan: StudyPlan = {
      ...plan,
      id,
      progress: 0,
      isActive: true,
      createdAt: new Date()
    };
    this.studyPlans.set(id, newPlan);
    return newPlan;
  }

  async updateStudyPlan(id: number, updates: Partial<StudyPlan>): Promise<StudyPlan> {
    const plan = this.studyPlans.get(id);
    if (!plan) throw new Error('Study plan not found');
    
    const updated = { ...plan, ...updates };
    this.studyPlans.set(id, updated);
    return updated;
  }
}

export const storage = new MemStorage();
