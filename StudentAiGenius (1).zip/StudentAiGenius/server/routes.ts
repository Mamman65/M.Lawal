import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { solveQuestion, provideTutoring, analyzeImage, transcribeAudio } from "./openai";
import { insertQuestionSchema, insertSolutionSchema, insertStudySessionSchema } from "@shared/schema";
import multer from "multer";
import sharp from "sharp";

const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Get user stats
  app.get("/api/user/:id/stats", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const stats = await storage.getUserStats(userId);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch user stats" });
    }
  });

  // Get user questions
  app.get("/api/user/:id/questions", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const questions = await storage.getQuestionsByUser(userId);
      res.json(questions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch questions" });
    }
  });

  // Create and solve question
  app.post("/api/questions", upload.single("image"), async (req, res) => {
    try {
      const { content, subject, difficulty, userId } = req.body;
      
      let imageBase64: string | undefined;
      let imageUrl: string | undefined;
      
      if (req.file) {
        // Process image with sharp
        const processedImage = await sharp(req.file.buffer)
          .resize(1024, 1024, { fit: 'inside', withoutEnlargement: true })
          .jpeg({ quality: 80 })
          .toBuffer();
        
        imageBase64 = processedImage.toString('base64');
        imageUrl = `data:image/jpeg;base64,${imageBase64}`;
      }

      // Validate input
      const questionData = insertQuestionSchema.parse({
        content,
        subject,
        difficulty,
        imageUrl
      });

      // Create question
      const question = await storage.createQuestion({
        ...questionData,
        userId: parseInt(userId)
      });

      // Solve question using AI
      const solution = await solveQuestion(content, subject, imageBase64);

      // Store solution
      const solutionData = insertSolutionSchema.parse({
        questionId: question.id,
        content: solution.solution,
        steps: solution.steps,
        explanation: solution.explanation
      });

      const savedSolution = await storage.createSolution(solutionData);

      res.json({
        question,
        solution: savedSolution,
        aiSolution: solution
      });
    } catch (error) {
      console.error("Error creating question:", error);
      res.status(500).json({ error: "Failed to create and solve question" });
    }
  });

  // Get question with solution
  app.get("/api/questions/:id", async (req, res) => {
    try {
      const questionId = parseInt(req.params.id);
      const question = await storage.getQuestion(questionId);
      
      if (!question) {
        return res.status(404).json({ error: "Question not found" });
      }

      const solution = await storage.getSolutionByQuestion(questionId);
      
      res.json({
        question,
        solution
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch question" });
    }
  });

  // AI Tutoring endpoint
  app.post("/api/tutor", async (req, res) => {
    try {
      const { topic, message, difficulty } = req.body;
      
      if (!topic || !message) {
        return res.status(400).json({ error: "Topic and message are required" });
      }

      const tutorResponse = await provideTutoring(topic, message, difficulty);
      res.json(tutorResponse);
    } catch (error) {
      console.error("Error in tutoring:", error);
      res.status(500).json({ error: "Failed to provide tutoring response" });
    }
  });

  // Image analysis endpoint
  app.post("/api/analyze-image", upload.single("image"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No image file provided" });
      }

      // Process image
      const processedImage = await sharp(req.file.buffer)
        .resize(1024, 1024, { fit: 'inside', withoutEnlargement: true })
        .jpeg({ quality: 80 })
        .toBuffer();
      
      const imageBase64 = processedImage.toString('base64');
      const analysis = await analyzeImage(imageBase64);

      res.json({
        analysis,
        imageUrl: `data:image/jpeg;base64,${imageBase64}`
      });
    } catch (error) {
      console.error("Error analyzing image:", error);
      res.status(500).json({ error: "Failed to analyze image" });
    }
  });

  // Audio transcription endpoint
  app.post("/api/transcribe", upload.single("audio"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No audio file provided" });
      }

      const transcription = await transcribeAudio(req.file.buffer);
      res.json({ transcription });
    } catch (error) {
      console.error("Error transcribing audio:", error);
      res.status(500).json({ error: "Failed to transcribe audio" });
    }
  });

  // Study sessions
  app.post("/api/study-sessions", async (req, res) => {
    try {
      const { subject, duration, questionsAnswered, accuracy, userId } = req.body;
      
      const sessionData = insertStudySessionSchema.parse({
        subject,
        duration: parseInt(duration),
        questionsAnswered: parseInt(questionsAnswered),
        accuracy: parseInt(accuracy)
      });

      const session = await storage.createStudySession({
        ...sessionData,
        userId: parseInt(userId)
      });

      res.json(session);
    } catch (error) {
      res.status(500).json({ error: "Failed to create study session" });
    }
  });

  // Get study sessions for user
  app.get("/api/user/:id/sessions", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const sessions = await storage.getStudySessionsByUser(userId);
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch study sessions" });
    }
  });

  // Get all formulas
  app.get("/api/formulas", async (req, res) => {
    try {
      const { subject } = req.query;
      
      let formulas;
      if (subject) {
        formulas = await storage.getFormulasBySubject(subject as string);
      } else {
        formulas = await storage.getAllFormulas();
      }
      
      res.json(formulas);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch formulas" });
    }
  });

  // Get specific formula
  app.get("/api/formulas/:id", async (req, res) => {
    try {
      const formulaId = parseInt(req.params.id);
      const formula = await storage.getFormula(formulaId);
      
      if (!formula) {
        return res.status(404).json({ error: "Formula not found" });
      }

      res.json(formula);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch formula" });
    }
  });

  // Get user achievements
  app.get("/api/user/:id/achievements", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const achievements = await storage.getAchievementsByUser(userId);
      res.json(achievements);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch achievements" });
    }
  });

  // Flashcard routes
  app.get("/api/flashcards/user/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { subject } = req.query;
      
      let flashcards;
      if (subject) {
        flashcards = await storage.getFlashcardsBySubject(userId, subject as string);
      } else {
        flashcards = await storage.getFlashcardsByUser(userId);
      }
      
      res.json(flashcards);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch flashcards" });
    }
  });

  app.post("/api/flashcards", async (req, res) => {
    try {
      const flashcard = await storage.createFlashcard(req.body);
      res.json(flashcard);
    } catch (error) {
      res.status(500).json({ error: "Failed to create flashcard" });
    }
  });

  app.patch("/api/flashcards/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const flashcard = await storage.updateFlashcard(id, req.body);
      res.json(flashcard);
    } catch (error) {
      res.status(500).json({ error: "Failed to update flashcard" });
    }
  });

  app.delete("/api/flashcards/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteFlashcard(id);
      if (success) {
        res.json({ success: true });
      } else {
        res.status(404).json({ error: "Flashcard not found" });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to delete flashcard" });
    }
  });

  // Quiz routes
  app.get("/api/quizzes/user/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const quizzes = await storage.getQuizzesByUser(userId);
      res.json(quizzes);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch quizzes" });
    }
  });

  app.get("/api/quizzes/subject/:subject", async (req, res) => {
    try {
      const subject = req.params.subject;
      const quizzes = await storage.getQuizzesBySubject(subject);
      res.json(quizzes);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch quizzes" });
    }
  });

  app.post("/api/quizzes", async (req, res) => {
    try {
      const quiz = await storage.createQuiz(req.body);
      res.json(quiz);
    } catch (error) {
      res.status(500).json({ error: "Failed to create quiz" });
    }
  });

  // Quiz attempt routes
  app.get("/api/quiz-attempts/user/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const attempts = await storage.getQuizAttemptsByUser(userId);
      res.json(attempts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch quiz attempts" });
    }
  });

  app.get("/api/quiz-attempts/quiz/:id", async (req, res) => {
    try {
      const quizId = parseInt(req.params.id);
      const attempts = await storage.getQuizAttemptsByQuiz(quizId);
      res.json(attempts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch quiz attempts" });
    }
  });

  app.post("/api/quiz-attempts", async (req, res) => {
    try {
      const attempt = await storage.createQuizAttempt(req.body);
      res.json(attempt);
    } catch (error) {
      res.status(500).json({ error: "Failed to create quiz attempt" });
    }
  });

  // Study plan routes
  app.get("/api/study-plans/user/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const plans = await storage.getStudyPlansByUser(userId);
      res.json(plans);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch study plans" });
    }
  });

  app.post("/api/study-plans", async (req, res) => {
    try {
      const plan = await storage.createStudyPlan(req.body);
      res.json(plan);
    } catch (error) {
      res.status(500).json({ error: "Failed to create study plan" });
    }
  });

  app.patch("/api/study-plans/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const plan = await storage.updateStudyPlan(id, req.body);
      res.json(plan);
    } catch (error) {
      res.status(500).json({ error: "Failed to update study plan" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
