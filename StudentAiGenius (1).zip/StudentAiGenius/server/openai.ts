import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export interface QuestionSolution {
  solution: string;
  steps: string[];
  explanation: string;
  confidence: number;
}

export interface TutorResponse {
  response: string;
  suggestedTopics: string[];
  difficulty: string;
  nextSteps: string[];
}

export async function solveQuestion(
  question: string, 
  subject?: string,
  imageBase64?: string
): Promise<QuestionSolution> {
  try {
    const messages: any[] = [
      {
        role: "system",
        content: `You are an expert educational AI tutor. Solve the given ${subject || "academic"} question with detailed step-by-step explanation. 
        Respond with JSON in this format: 
        {
          "solution": "final answer",
          "steps": ["step 1", "step 2", "step 3"],
          "explanation": "detailed explanation of the solution process",
          "confidence": 0.95
        }`
      }
    ];

    if (imageBase64) {
      messages.push({
        role: "user",
        content: [
          {
            type: "text",
            text: `Please solve this ${subject || "academic"} problem from the image: ${question}`
          },
          {
            type: "image_url",
            image_url: {
              url: `data:image/jpeg;base64,${imageBase64}`
            }
          }
        ]
      });
    } else {
      messages.push({
        role: "user",
        content: `Please solve this ${subject || "academic"} question: ${question}`
      });
    }

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages,
      response_format: { type: "json_object" },
      max_tokens: 1000
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return {
      solution: result.solution || "Unable to provide solution",
      steps: result.steps || [],
      explanation: result.explanation || "No explanation available",
      confidence: result.confidence || 0.5
    };
  } catch (error) {
    console.error("Error solving question:", error);
    throw new Error("Failed to solve question: " + (error as Error).message);
  }
}

export async function provideTutoring(
  topic: string,
  userMessage: string,
  difficulty: string = "intermediate"
): Promise<TutorResponse> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are a patient and knowledgeable AI tutor specializing in ${topic}. 
          Provide clear, educational responses at ${difficulty} level.
          Respond with JSON in this format:
          {
            "response": "your educational response",
            "suggestedTopics": ["related topic 1", "related topic 2"],
            "difficulty": "current difficulty level",
            "nextSteps": ["what to study next", "practice suggestions"]
          }`
        },
        {
          role: "user",
          content: userMessage
        }
      ],
      response_format: { type: "json_object" },
      max_tokens: 800
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return {
      response: result.response || "I'd be happy to help you learn more about this topic.",
      suggestedTopics: result.suggestedTopics || [],
      difficulty: result.difficulty || difficulty,
      nextSteps: result.nextSteps || []
    };
  } catch (error) {
    console.error("Error providing tutoring:", error);
    throw new Error("Failed to provide tutoring: " + (error as Error).message);
  }
}

export async function analyzeImage(base64Image: string): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Analyze this educational image and extract any questions, problems, or text content. Describe what you see in detail."
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${base64Image}`
              }
            }
          ]
        }
      ],
      max_tokens: 500
    });

    return response.choices[0].message.content || "Unable to analyze image";
  } catch (error) {
    console.error("Error analyzing image:", error);
    throw new Error("Failed to analyze image: " + (error as Error).message);
  }
}

export async function transcribeAudio(audioBuffer: Buffer): Promise<string> {
  try {
    // Create a temporary file-like object from the buffer
    const audioFile = new File([audioBuffer], "audio.webm", { type: "audio/webm" });
    
    const transcription = await openai.audio.transcriptions.create({
      file: audioFile as any,
      model: "whisper-1",
    });

    return transcription.text;
  } catch (error) {
    console.error("Error transcribing audio:", error);
    throw new Error("Failed to transcribe audio: " + (error as Error).message);
  }
}
