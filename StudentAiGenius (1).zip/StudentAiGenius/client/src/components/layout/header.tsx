import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bell, Brain, User } from "lucide-react";
import { useLocation } from "wouter";

export default function Header() {
  const [location] = useLocation();

  const getPageTitle = () => {
    switch (location) {
      case "/": return "Dashboard";
      case "/solve": return "Solve Questions";
      case "/scan": return "Photo Scan";
      case "/tutor": return "AI Tutor";
      case "/formulas": return "Formula Lab";
      case "/progress": return "Progress";
      default: return "Dashboard";
    }
  };

  return (
    <header className="bg-dark-surface/80 backdrop-blur-md border-b border-gray-800 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-red-gradient rounded-xl flex items-center justify-center">
              <Brain className="text-white w-5 h-5" />
            </div>
            <div>
              <span className="text-xl font-bold text-gradient-red">STUDENT AI</span>
              <div className="hidden sm:block">
                <span className="text-sm text-muted-foreground ml-2">
                  {getPageTitle()}
                </span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="w-5 h-5 text-muted-foreground hover:text-foreground transition-colors" />
              <Badge className="absolute -top-1 -right-1 w-2 h-2 p-0 bg-red-500">
                <span className="sr-only">New notifications</span>
              </Badge>
            </Button>
            
            <div className="w-8 h-8 bg-red-gradient rounded-full flex items-center justify-center">
              <User className="text-white w-4 h-4" />
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
