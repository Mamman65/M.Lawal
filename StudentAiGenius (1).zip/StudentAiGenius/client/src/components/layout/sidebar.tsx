import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Home, Brain, Camera, MicOff, GraduationCap, FlaskRound, TrendingUp, BookOpen, Zap, Calendar } from "lucide-react";
import { useLocation } from "wouter";

const navigation = [
  { name: "Dashboard", href: "/", icon: Home },
  { name: "Solve Questions", href: "/solve", icon: Brain },
  { name: "Photo Scan", href: "/scan", icon: Camera },
  { name: "AI Tutor", href: "/tutor", icon: GraduationCap },
  { name: "Formula Lab", href: "/formulas", icon: FlaskRound },
  { name: "Flashcards", href: "/flashcards", icon: BookOpen },
  { name: "Quiz Center", href: "/quizzes", icon: Zap },
  { name: "Study Planner", href: "/study-planner", icon: Calendar },
  { name: "Progress", href: "/progress", icon: TrendingUp },
];

export default function Sidebar() {
  const [location, setLocation] = useLocation();

  return (
    <aside className="w-64 bg-dark-surface h-screen sticky top-16 border-r border-gray-800 hidden lg:block">
      <nav className="p-6 space-y-2">
        {navigation.map((item) => {
          const isActive = location === item.href;
          return (
            <Button
              key={item.name}
              variant="ghost"
              className={cn(
                "w-full justify-start space-x-3 px-4 py-3 rounded-xl transition-all",
                isActive
                  ? "bg-red-gradient text-white"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted"
              )}
              onClick={() => item.href !== "#" && setLocation(item.href)}
              disabled={item.href === "#"}
            >
              <item.icon className="w-5 h-5" />
              <span className="font-medium">{item.name}</span>
            </Button>
          );
        })}
      </nav>
    </aside>
  );
}
