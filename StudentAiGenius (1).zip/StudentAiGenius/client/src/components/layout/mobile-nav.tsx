import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Home, Brain, BookOpen, Zap, TrendingUp } from "lucide-react";
import { useLocation } from "wouter";

const navigation = [
  { name: "Home", href: "/", icon: Home },
  { name: "Solve", href: "/solve", icon: Brain },
  { name: "Cards", href: "/flashcards", icon: BookOpen },
  { name: "Quiz", href: "/quizzes", icon: Zap },
  { name: "Progress", href: "/progress", icon: TrendingUp },
];

export default function MobileNav() {
  const [location, setLocation] = useLocation();

  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-dark-surface border-t border-gray-800 z-40">
      <div className="grid grid-cols-5 h-16">
        {navigation.map((item) => {
          const isActive = location === item.href;
          return (
            <Button
              key={item.name}
              variant="ghost"
              className={cn(
                "flex flex-col items-center justify-center h-full rounded-none",
                isActive
                  ? "text-primary"
                  : "text-muted-foreground hover:text-foreground"
              )}
              onClick={() => setLocation(item.href)}
            >
              <item.icon className="w-5 h-5 mb-1" />
              <span className="text-xs">{item.name}</span>
            </Button>
          );
        })}
      </div>
    </nav>
  );
}
