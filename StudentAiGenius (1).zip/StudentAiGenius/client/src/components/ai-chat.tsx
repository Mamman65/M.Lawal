import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Brain, User, Lightbulb, ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { useEffect, useRef } from "react";

interface ChatMessage {
  id: string;
  type: 'user' | 'tutor';
  content: string;
  timestamp: Date;
  metadata?: {
    suggestedTopics?: string[];
    nextSteps?: string[];
    difficulty?: string;
  };
}

interface AiChatProps {
  messages: ChatMessage[];
  isTyping?: boolean;
  onSuggestedTopicClick?: (topic: string) => void;
  onNextStepClick?: (step: string) => void;
}

export default function AiChat({ 
  messages, 
  isTyping = false,
  onSuggestedTopicClick,
  onNextStepClick 
}: AiChatProps) {
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <ScrollArea ref={scrollAreaRef} className="h-full w-full">
      <div className="space-y-4 p-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={cn(
              "flex gap-3",
              message.type === 'user' ? "justify-end" : "justify-start"
            )}
          >
            {message.type === 'tutor' && (
              <div className="w-8 h-8 bg-green-gradient rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                <Brain className="w-4 h-4 text-white" />
              </div>
            )}
            
            <div className={cn(
              "max-w-[80%] space-y-2",
              message.type === 'user' ? "items-end" : "items-start"
            )}>
              <div className={cn(
                "rounded-2xl px-4 py-3",
                message.type === 'user'
                  ? "bg-red-gradient text-white"
                  : "bg-muted border border-border"
              )}>
                <p className="text-sm leading-relaxed whitespace-pre-wrap">
                  {message.content}
                </p>
              </div>
              
              {/* Metadata for tutor messages */}
              {message.type === 'tutor' && message.metadata && (
                <div className="space-y-2">
                  {/* Difficulty badge */}
                  {message.metadata.difficulty && (
                    <Badge variant="secondary" className="text-xs">
                      {message.metadata.difficulty} level
                    </Badge>
                  )}
                  
                  {/* Suggested topics */}
                  {message.metadata.suggestedTopics && message.metadata.suggestedTopics.length > 0 && (
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground flex items-center gap-1">
                        <Lightbulb className="w-3 h-3" />
                        Related topics:
                      </p>
                      <div className="flex flex-wrap gap-1">
                        {message.metadata.suggestedTopics.map((topic, index) => (
                          <Button
                            key={index}
                            variant="outline"
                            size="sm"
                            className="h-6 text-xs border-border hover:bg-muted"
                            onClick={() => onSuggestedTopicClick?.(topic)}
                          >
                            {topic}
                          </Button>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  {/* Next steps */}
                  {message.metadata.nextSteps && message.metadata.nextSteps.length > 0 && (
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground flex items-center gap-1">
                        <ArrowRight className="w-3 h-3" />
                        Next steps:
                      </p>
                      <div className="space-y-1">
                        {message.metadata.nextSteps.map((step, index) => (
                          <Button
                            key={index}
                            variant="ghost"
                            size="sm"
                            className="h-auto p-2 text-xs text-left justify-start hover:bg-muted"
                            onClick={() => onNextStepClick?.(step)}
                          >
                            <span className="text-muted-foreground mr-2">{index + 1}.</span>
                            {step}
                          </Button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
              
              <p className="text-xs text-muted-foreground px-1">
                {formatTime(message.timestamp)}
              </p>
            </div>
            
            {message.type === 'user' && (
              <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                <User className="w-4 h-4 text-muted-foreground" />
              </div>
            )}
          </div>
        ))}
        
        {/* Typing indicator */}
        {isTyping && (
          <div className="flex gap-3 justify-start">
            <div className="w-8 h-8 bg-green-gradient rounded-full flex items-center justify-center flex-shrink-0 mt-1">
              <Brain className="w-4 h-4 text-white" />
            </div>
            <div className="bg-muted border border-border rounded-2xl px-4 py-3">
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          </div>
        )}
        
        <div ref={bottomRef} />
      </div>
    </ScrollArea>
  );
}
