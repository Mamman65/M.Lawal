import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Trophy, Star, Zap, Target, BookOpen, Brain, Clock, Medal, Award, Crown } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Achievement } from "@shared/schema";

const MOCK_USER_ID = 1;

interface AchievementTemplate {
  id: string;
  name: string;
  description: string;
  icon: any;
  category: string;
  requirement: number;
  currentProgress: number;
  badgeColor: string;
  rarity: "common" | "rare" | "epic" | "legendary";
}

export default function AchievementSystem() {
  const [selectedAchievement, setSelectedAchievement] = useState<AchievementTemplate | null>(null);
  const [showNewAchievement, setShowNewAchievement] = useState(false);
  const [newAchievementData, setNewAchievementData] = useState<AchievementTemplate | null>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: userAchievements = [] } = useQuery({
    queryKey: [`/api/user/${MOCK_USER_ID}/achievements`],
  });

  const { data: userStats } = useQuery({
    queryKey: [`/api/user/${MOCK_USER_ID}/stats`],
  });

  const createAchievementMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/achievements", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/user/${MOCK_USER_ID}/achievements`] });
    },
  });

  // Achievement templates with progress tracking
  const achievementTemplates: AchievementTemplate[] = [
    {
      id: "first_question",
      name: "First Steps",
      description: "Solve your first question",
      icon: Brain,
      category: "Questions",
      requirement: 1,
      currentProgress: userStats?.totalQuestions || 0,
      badgeColor: "bg-green-500",
      rarity: "common"
    },
    {
      id: "question_streak_5",
      name: "Getting Started",
      description: "Solve 5 questions in a row",
      icon: Zap,
      category: "Questions",
      requirement: 5,
      currentProgress: userStats?.totalQuestions || 0,
      badgeColor: "bg-blue-500",
      rarity: "common"
    },
    {
      id: "question_master",
      name: "Question Master",
      description: "Solve 50 questions",
      icon: Trophy,
      category: "Questions",
      requirement: 50,
      currentProgress: userStats?.totalQuestions || 0,
      badgeColor: "bg-yellow-500",
      rarity: "rare"
    },
    {
      id: "study_warrior",
      name: "Study Warrior",
      description: "Study for 10 hours total",
      icon: Clock,
      category: "Study Time",
      requirement: 600, // 10 hours in minutes
      currentProgress: userStats?.totalStudyTime || 0,
      badgeColor: "bg-purple-500",
      rarity: "epic"
    },
    {
      id: "flashcard_creator",
      name: "Card Creator",
      description: "Create 20 flashcards",
      icon: BookOpen,
      category: "Flashcards",
      requirement: 20,
      currentProgress: Math.floor(Math.random() * 25), // Mock progress
      badgeColor: "bg-orange-500",
      rarity: "common"
    },
    {
      id: "quiz_champion",
      name: "Quiz Champion",
      description: "Score 90% or higher on 5 quizzes",
      icon: Medal,
      category: "Quizzes",
      requirement: 5,
      currentProgress: Math.floor(Math.random() * 6), // Mock progress
      badgeColor: "bg-red-500",
      rarity: "rare"
    },
    {
      id: "perfect_week",
      name: "Perfect Week",
      description: "Study every day for a week",
      icon: Star,
      category: "Consistency",
      requirement: 7,
      currentProgress: Math.floor(Math.random() * 8), // Mock progress
      badgeColor: "bg-pink-500",
      rarity: "epic"
    },
    {
      id: "ai_whisperer",
      name: "AI Whisperer",
      description: "Have 100 conversations with the AI tutor",
      icon: Crown,
      category: "AI Tutor",
      requirement: 100,
      currentProgress: Math.floor(Math.random() * 110), // Mock progress
      badgeColor: "bg-indigo-500",
      rarity: "legendary"
    }
  ];

  // Check for newly earned achievements
  useEffect(() => {
    const newlyEarned = achievementTemplates.find(template => {
      const isEarned = template.currentProgress >= template.requirement;
      const alreadyHas = userAchievements.some((ach: Achievement) => ach.name === template.name);
      return isEarned && !alreadyHas;
    });

    if (newlyEarned) {
      setNewAchievementData(newlyEarned);
      setShowNewAchievement(true);
      
      // Award the achievement
      createAchievementMutation.mutate({
        name: newlyEarned.name,
        description: newlyEarned.description,
        badgeUrl: `/badges/${newlyEarned.id}.svg`,
        userId: MOCK_USER_ID,
      });

      toast({
        title: "Achievement Unlocked!",
        description: `You earned "${newlyEarned.name}"`,
      });
    }
  }, [userStats, userAchievements]);

  const earnedAchievements = achievementTemplates.filter(template =>
    userAchievements.some((ach: Achievement) => ach.name === template.name)
  );

  const availableAchievements = achievementTemplates.filter(template =>
    !userAchievements.some((ach: Achievement) => ach.name === template.name)
  );

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case "common": return "text-gray-400 bg-gray-500/20";
      case "rare": return "text-blue-400 bg-blue-500/20";
      case "epic": return "text-purple-400 bg-purple-500/20";
      case "legendary": return "text-yellow-400 bg-yellow-500/20";
      default: return "text-gray-400 bg-gray-500/20";
    }
  };

  return (
    <div className="space-y-6">
      {/* Achievement Overview */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Trophy className="w-5 h-5 text-yellow-400" />
            <span>Achievement Progress</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <h3 className="text-2xl font-bold text-yellow-400">{earnedAchievements.length}</h3>
              <p className="text-sm text-muted-foreground">Earned</p>
            </div>
            <div className="text-center">
              <h3 className="text-2xl font-bold text-blue-400">{availableAchievements.length}</h3>
              <p className="text-sm text-muted-foreground">Available</p>
            </div>
            <div className="text-center">
              <h3 className="text-2xl font-bold text-green-400">
                {Math.round((earnedAchievements.length / achievementTemplates.length) * 100)}%
              </h3>
              <p className="text-sm text-muted-foreground">Completion</p>
            </div>
            <div className="text-center">
              <h3 className="text-2xl font-bold text-purple-400">
                {earnedAchievements.filter(a => a.rarity === "legendary").length}
              </h3>
              <p className="text-sm text-muted-foreground">Legendary</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Earned Achievements */}
      {earnedAchievements.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold mb-4 flex items-center space-x-2">
            <Award className="w-5 h-5 text-yellow-400" />
            <span>Earned Achievements</span>
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {earnedAchievements.map((achievement) => (
              <Card key={achievement.id} className="bg-card border-border cursor-pointer hover:bg-muted/50 transition-colors">
                <CardContent className="p-4">
                  <div className="flex items-start space-x-3">
                    <div className={`p-2 rounded-full ${achievement.badgeColor}`}>
                      <achievement.icon className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="font-medium">{achievement.name}</h4>
                        <Badge className={getRarityColor(achievement.rarity)}>
                          {achievement.rarity}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">{achievement.description}</p>
                      <Badge variant="outline" className="text-green-400 border-green-400">
                        ✓ Completed
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Available Achievements */}
      <div>
        <h3 className="text-lg font-semibold mb-4 flex items-center space-x-2">
          <Target className="w-5 h-5 text-blue-400" />
          <span>Available Achievements</span>
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {availableAchievements.map((achievement) => (
            <Card key={achievement.id} className="bg-card border-border cursor-pointer hover:bg-muted/50 transition-colors"
                  onClick={() => setSelectedAchievement(achievement)}>
              <CardContent className="p-4">
                <div className="flex items-start space-x-3">
                  <div className="p-2 rounded-full bg-muted">
                    <achievement.icon className="w-6 h-6 text-muted-foreground" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="font-medium">{achievement.name}</h4>
                      <Badge className={getRarityColor(achievement.rarity)}>
                        {achievement.rarity}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">{achievement.description}</p>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between text-xs">
                        <span>Progress</span>
                        <span>{Math.min(achievement.currentProgress, achievement.requirement)}/{achievement.requirement}</span>
                      </div>
                      <Progress 
                        value={(achievement.currentProgress / achievement.requirement) * 100} 
                        className="h-2"
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Achievement Detail Dialog */}
      <Dialog open={!!selectedAchievement} onOpenChange={() => setSelectedAchievement(null)}>
        <DialogContent className="bg-card border-border">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-3">
              {selectedAchievement && (
                <>
                  <div className="p-3 rounded-full bg-muted">
                    <selectedAchievement.icon className="w-8 h-8 text-muted-foreground" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold">{selectedAchievement.name}</h3>
                    <Badge className={getRarityColor(selectedAchievement.rarity)}>
                      {selectedAchievement.rarity}
                    </Badge>
                  </div>
                </>
              )}
            </DialogTitle>
          </DialogHeader>
          {selectedAchievement && (
            <div className="space-y-4">
              <p className="text-muted-foreground">{selectedAchievement.description}</p>
              
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Category:</span>
                  <Badge variant="outline">{selectedAchievement.category}</Badge>
                </div>
                <div className="flex justify-between">
                  <span>Progress:</span>
                  <span className="font-medium">
                    {Math.min(selectedAchievement.currentProgress, selectedAchievement.requirement)}/{selectedAchievement.requirement}
                  </span>
                </div>
              </div>

              <div className="space-y-2">
                <span className="text-sm font-medium">Progress</span>
                <Progress 
                  value={(selectedAchievement.currentProgress / selectedAchievement.requirement) * 100} 
                  className="h-3"
                />
              </div>

              <Button 
                onClick={() => setSelectedAchievement(null)}
                className="w-full"
              >
                Close
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* New Achievement Dialog */}
      <Dialog open={showNewAchievement} onOpenChange={setShowNewAchievement}>
        <DialogContent className="bg-card border-border text-center">
          <DialogHeader>
            <DialogTitle className="text-center">
              <div className="flex flex-col items-center space-y-4">
                <div className="relative">
                  <div className="absolute inset-0 animate-ping bg-yellow-400 rounded-full opacity-75"></div>
                  <div className="relative p-4 bg-yellow-500 rounded-full">
                    <Trophy className="w-12 h-12 text-white" />
                  </div>
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-yellow-400">Achievement Unlocked!</h2>
                  <h3 className="text-xl font-semibold">{newAchievementData?.name}</h3>
                </div>
              </div>
            </DialogTitle>
          </DialogHeader>
          {newAchievementData && (
            <div className="space-y-4">
              <p className="text-muted-foreground">{newAchievementData.description}</p>
              <Badge className={getRarityColor(newAchievementData.rarity)} size="lg">
                {newAchievementData.rarity.toUpperCase()}
              </Badge>
              <Button 
                onClick={() => setShowNewAchievement(false)}
                className="w-full bg-yellow-gradient hover:opacity-90"
              >
                Awesome!
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}