import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { MicOff, MegaphoneOff, Volume2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { useVoiceRecognition } from "@/hooks/use-voice-recognition";
import { useToast } from "@/hooks/use-toast";

export default function VoiceAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const { toast } = useToast();
  
  const {
    isListening,
    transcript,
    startListening,
    stopListening,
    isSupported
  } = useVoiceRecognition({
    onResult: (result) => {
      toast({
        title: "Voice Command Received",
        description: `"${result}"`,
      });
      setIsOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Voice Recognition Error",
        description: error,
        variant: "destructive",
      });
    }
  });

  const handleToggleListening = () => {
    if (!isSupported) {
      toast({
        title: "Voice Recognition Not Supported",
        description: "Your browser doesn't support voice recognition.",
        variant: "destructive",
      });
      return;
    }

    if (isListening) {
      stopListening();
    } else {
      startListening();
      setIsOpen(true);
    }
  };

  return (
    <>
      {/* Floating Voice Button */}
      <div className="fixed bottom-6 right-6 z-50">
        <Button
          onClick={handleToggleListening}
          className={cn(
            "w-16 h-16 rounded-full shadow-2xl flex items-center justify-center text-white text-xl transition-all transform hover:scale-105",
            isListening
              ? "bg-red-500 hover:bg-red-600 animate-pulse"
              : "bg-red-gradient hover:shadow-red-500/25"
          )}
        >
          {isListening ? (
            <MegaphoneOff className="w-6 h-6" />
          ) : (
            <MicOff className="w-6 h-6" />
          )}
        </Button>
      </div>

      {/* Voice Recognition Modal */}
      {isOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-md bg-card border-border">
            <CardContent className="p-6">
              <div className="text-center space-y-4">
                <div className="relative">
                  <div className={cn(
                    "w-20 h-20 rounded-full mx-auto flex items-center justify-center",
                    isListening ? "bg-red-500/20" : "bg-muted"
                  )}>
                    {isListening ? (
                      <div className="relative">
                        <MicOff className="w-8 h-8 text-red-400" />
                        <div className="absolute inset-0 rounded-full border-2 border-red-400 animate-ping" />
                      </div>
                    ) : (
                      <Volume2 className="w-8 h-8 text-muted-foreground" />
                    )}
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-2">
                    {isListening ? "Listening..." : "Voice Assistant"}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {isListening
                      ? "Speak your question now"
                      : "Click the microphone to start"
                    }
                  </p>
                </div>

                {transcript && (
                  <div className="bg-muted rounded-lg p-3">
                    <p className="text-sm">{transcript}</p>
                  </div>
                )}

                <div className="flex space-x-3">
                  <Button
                    variant="outline"
                    onClick={() => setIsOpen(false)}
                    className="flex-1 border-border"
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={handleToggleListening}
                    className={cn(
                      "flex-1",
                      isListening
                        ? "bg-red-500 hover:bg-red-600"
                        : "bg-red-gradient hover:opacity-90"
                    )}
                  >
                    {isListening ? "Stop" : "Start"}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </>
  );
}
