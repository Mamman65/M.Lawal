import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Camera, Upload, FileText, Eye, Download, Trash2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import ImageUpload from "@/components/image-upload";

interface ScanResult {
  analysis: string;
  imageUrl: string;
}

export default function Scan() {
  const [scannedImages, setScannedImages] = useState<ScanResult[]>([]);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  
  const { toast } = useToast();

  const scanMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("image", file);
      const response = await apiRequest("POST", "/api/analyze-image", formData);
      return response.json();
    },
    onSuccess: (data: ScanResult) => {
      setScannedImages(prev => [data, ...prev]);
      toast({
        title: "Image Scanned Successfully!",
        description: "Your image has been analyzed and processed.",
      });
    },
    onError: (error) => {
      toast({
        title: "Scan Failed",
        description: "Failed to analyze the image. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleImageSelect = (file: File) => {
    scanMutation.mutate(file);
  };

  const handleImageClick = (imageUrl: string) => {
    setSelectedImage(imageUrl);
  };

  const handleDeleteImage = (index: number) => {
    setScannedImages(prev => prev.filter((_, i) => i !== index));
    toast({
      title: "Image Deleted",
      description: "The scanned image has been removed.",
    });
  };

  const downloadImage = (imageUrl: string, index: number) => {
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = `scanned-image-${index + 1}.jpg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const supportedFormats = [
    { name: "JPEG", ext: ".jpg, .jpeg" },
    { name: "PNG", ext: ".png" },
    { name: "PDF", ext: ".pdf" },
    { name: "WEBP", ext: ".webp" }
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold mb-2">
          <span className="text-gradient-red">Smart Photo Scanner</span>
        </h1>
        <p className="text-muted-foreground">
          Upload exam papers, worksheets, or any educational content to extract and analyze text using AI.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Upload Section */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Camera className="w-5 h-5 text-primary" />
              <span>Upload Document</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <ImageUpload
              onImageSelect={handleImageSelect}
              className="border-2 border-dashed border-border rounded-xl p-8 text-center hover:border-primary transition-colors"
              disabled={scanMutation.isPending}
            >
              <div className="space-y-4">
                <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto">
                  {scanMutation.isPending ? (
                    <Upload className="w-8 h-8 text-primary animate-pulse" />
                  ) : (
                    <Camera className="w-8 h-8 text-primary" />
                  )}
                </div>
                <div>
                  <h3 className="text-lg font-medium mb-2">
                    {scanMutation.isPending ? "Processing..." : "Upload Your Document"}
                  </h3>
                  <p className="text-muted-foreground text-sm">
                    Drag & drop or click to upload exam papers, worksheets, or handwritten notes
                  </p>
                </div>
                <Button 
                  variant="outline" 
                  className="border-border"
                  disabled={scanMutation.isPending}
                >
                  <Upload className="w-4 h-4 mr-2" />
                  Choose File
                </Button>
              </div>
            </ImageUpload>

            {/* Supported Formats */}
            <div className="space-y-3">
              <h4 className="font-medium">Supported Formats:</h4>
              <div className="grid grid-cols-2 gap-2">
                {supportedFormats.map((format) => (
                  <Badge key={format.name} variant="outline" className="justify-center border-border">
                    {format.name} {format.ext}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Max file size:</span>
                <span>10MB</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Processing time:</span>
                <span>~10 seconds</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results Section */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <FileText className="w-5 h-5 text-green-400" />
              <span>Scan Results</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {scannedImages.length > 0 ? (
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {scannedImages.map((result, index) => (
                  <Card key={index} className="bg-muted border-border">
                    <CardContent className="p-4">
                      <div className="flex items-start space-x-3">
                        <img
                          src={result.imageUrl}
                          alt={`Scan ${index + 1}`}
                          className="w-16 h-16 object-cover rounded-lg cursor-pointer hover:opacity-80 transition-opacity"
                          onClick={() => handleImageClick(result.imageUrl)}
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-2">
                            <Badge variant="secondary" className="bg-green-500/20 text-green-400">
                              Scan #{index + 1}
                            </Badge>
                            <div className="flex space-x-1">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleImageClick(result.imageUrl)}
                              >
                                <Eye className="w-4 h-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => downloadImage(result.imageUrl, index)}
                              >
                                <Download className="w-4 h-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleDeleteImage(index)}
                                className="text-red-400 hover:text-red-300"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                          <p className="text-sm text-muted-foreground line-clamp-3">
                            {result.analysis}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">
                  No scanned documents yet. Upload an image to get started.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Image Preview Modal */}
      {selectedImage && (
        <div 
          className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4"
          onClick={() => setSelectedImage(null)}
        >
          <div className="max-w-4xl max-h-full">
            <img
              src={selectedImage}
              alt="Full size view"
              className="max-w-full max-h-full object-contain"
              onClick={(e) => e.stopPropagation()}
            />
            <Button
              variant="outline"
              className="absolute top-4 right-4"
              onClick={() => setSelectedImage(null)}
            >
              Close
            </Button>
          </div>
        </div>
      )}

      {/* Tips Section */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle>Tips for Better Scanning</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <h4 className="font-medium text-green-400">✓ Do This:</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Use good lighting</li>
                <li>• Keep text straight and clear</li>
                <li>• Use high contrast backgrounds</li>
                <li>• Ensure text is not blurry</li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="font-medium text-red-400">✗ Avoid This:</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Shadows over text</li>
                <li>• Tilted or angled photos</li>
                <li>• Very small text</li>
                <li>• Damaged or faded documents</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
