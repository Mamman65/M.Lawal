import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Brain, Camera, MicOff, Clock, CheckCircle, AlertCircle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import ImageUpload from "@/components/image-upload";

const MOCK_USER_ID = 1;

interface SolutionResponse {
  question: any;
  solution: any;
  aiSolution: {
    solution: string;
    steps: string[];
    explanation: string;
    confidence: number;
  };
}

export default function Solve() {
  const [question, setQuestion] = useState("");
  const [selectedSubject, setSelectedSubject] = useState("");
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [solution, setSolution] = useState<SolutionResponse | null>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const solveMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await apiRequest("POST", "/api/questions", formData);
      return response.json();
    },
    onSuccess: (data) => {
      setSolution(data);
      setQuestion("");
      setSelectedImage(null);
      setImagePreview(null);
      queryClient.invalidateQueries({ queryKey: [`/api/user/${MOCK_USER_ID}/questions`] });
      toast({
        title: "Question Solved!",
        description: "Your question has been solved successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to solve question. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSolveQuestion = () => {
    if (!question.trim() && !selectedImage) {
      toast({
        title: "Input Required",
        description: "Please enter a question or upload an image.",
        variant: "destructive",
      });
      return;
    }

    const formData = new FormData();
    formData.append("content", question);
    formData.append("subject", selectedSubject);
    formData.append("difficulty", "intermediate");
    formData.append("userId", MOCK_USER_ID.toString());
    
    if (selectedImage) {
      formData.append("image", selectedImage);
    }

    solveMutation.mutate(formData);
  };

  const handleImageSelect = (file: File) => {
    setSelectedImage(file);
    const reader = new FileReader();
    reader.onload = (e) => {
      setImagePreview(e.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const subjects = [
    { value: "mathematics", label: "Mathematics" },
    { value: "physics", label: "Physics" },
    { value: "chemistry", label: "Chemistry" },
    { value: "engineering", label: "Engineering" },
    { value: "computer-science", label: "Computer Science" },
    { value: "biology", label: "Biology" },
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold mb-2">
          <span className="text-gradient-red">AI Question Solver</span>
        </h1>
        <p className="text-muted-foreground">
          Get instant solutions with detailed step-by-step explanations for any academic question.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Input Section */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Brain className="w-5 h-5 text-primary" />
              <span>Ask Your Question</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Subject</label>
              <Select value={selectedSubject} onValueChange={setSelectedSubject}>
                <SelectTrigger className="bg-muted border-border">
                  <SelectValue placeholder="Select subject" />
                </SelectTrigger>
                <SelectContent>
                  {subjects.map((subject) => (
                    <SelectItem key={subject.value} value={subject.value}>
                      {subject.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Question</label>
              <Textarea
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="Type your question here..."
                className="min-h-[120px] bg-muted border-border"
              />
            </div>

            {imagePreview && (
              <div className="border border-border rounded-lg p-4">
                <p className="text-sm font-medium mb-2">Uploaded Image:</p>
                <img 
                  src={imagePreview} 
                  alt="Question" 
                  className="max-w-full h-auto rounded-lg"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setSelectedImage(null);
                    setImagePreview(null);
                  }}
                  className="mt-2"
                >
                  Remove Image
                </Button>
              </div>
            )}

            <div className="flex items-center space-x-3">
              <Button
                onClick={handleSolveQuestion}
                disabled={solveMutation.isPending}
                className="flex-1 bg-red-gradient hover:opacity-90"
              >
                {solveMutation.isPending ? (
                  <>
                    <Clock className="w-4 h-4 mr-2 animate-spin" />
                    Solving...
                  </>
                ) : (
                  <>
                    <Brain className="w-4 h-4 mr-2" />
                    Solve Question
                  </>
                )}
              </Button>
              <ImageUpload onImageSelect={handleImageSelect} />
              <Button variant="outline" size="icon" className="border-border">
                <MicOff className="w-4 h-4" />
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Solution Section */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <CheckCircle className="w-5 h-5 text-green-400" />
              <span>Solution</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {solution ? (
              <div className="space-y-6">
                {/* Confidence and Subject */}
                <div className="flex items-center justify-between">
                  <Badge variant="secondary" className="bg-green-500/20 text-green-400">
                    {Math.round(solution.aiSolution.confidence * 100)}% Confidence
                  </Badge>
                  <Badge variant="outline" className="border-border">
                    {solution.question.subject}
                  </Badge>
                </div>

                {/* Final Answer */}
                <div>
                  <h3 className="text-lg font-semibold mb-2 text-primary">Answer:</h3>
                  <Card className="bg-green-500/10 border-green-500/20">
                    <CardContent className="p-4">
                      <p className="text-green-400 font-medium">{solution.aiSolution.solution}</p>
                    </CardContent>
                  </Card>
                </div>

                {/* Step by Step Solution */}
                {solution.aiSolution.steps.length > 0 && (
                  <div>
                    <h3 className="text-lg font-semibold mb-3">Step-by-Step Solution:</h3>
                    <div className="space-y-3">
                      {solution.aiSolution.steps.map((step, index) => (
                        <div key={index} className="flex items-start space-x-3">
                          <div className="w-6 h-6 bg-blue-500/20 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                            <span className="text-blue-400 text-xs font-medium">{index + 1}</span>
                          </div>
                          <p className="text-sm">{step}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <Separator className="bg-border" />

                {/* Explanation */}
                <div>
                  <h3 className="text-lg font-semibold mb-2">Explanation:</h3>
                  <p className="text-muted-foreground">{solution.aiSolution.explanation}</p>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <AlertCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">
                  Enter a question above to get an AI-powered solution with detailed explanations.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
