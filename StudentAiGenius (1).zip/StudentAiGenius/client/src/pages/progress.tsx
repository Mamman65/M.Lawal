import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { TrendingUp, Clock, Target, Trophy, Calendar, BookOpen, Brain, Zap, Calculator, FlaskRound } from "lucide-react";
import { useState } from "react";

const MOCK_USER_ID = 1;

export default function ProgressPage() {
  const [selectedPeriod, setSelectedPeriod] = useState("7days");

  const { data: stats } = useQuery({
    queryKey: [`/api/user/${MOCK_USER_ID}/stats`],
  });

  const { data: sessions } = useQuery({
    queryKey: [`/api/user/${MOCK_USER_ID}/sessions`],
  });

  const { data: achievements } = useQuery({
    queryKey: [`/api/user/${MOCK_USER_ID}/achievements`],
  });

  const { data: questions } = useQuery({
    queryKey: [`/api/user/${MOCK_USER_ID}/questions`],
  });

  const periods = [
    { value: "7days", label: "Last 7 days" },
    { value: "30days", label: "Last 30 days" },
    { value: "90days", label: "Last 3 months" },
    { value: "1year", label: "Last year" },
  ];

  const subjects = [
    { name: "Mathematics", progress: 92, icon: Calculator, color: "text-blue-400" },
    { name: "Physics", progress: 78, icon: Zap, color: "text-purple-400" },
    { name: "Chemistry", progress: 65, icon: FlaskRound, color: "text-orange-400" },
    { name: "Computer Science", progress: 84, icon: Brain, color: "text-green-400" },
  ];

  const weeklyData = [
    { day: "Mon", questions: 12, hours: 2.5 },
    { day: "Tue", questions: 8, hours: 1.8 },
    { day: "Wed", questions: 15, hours: 3.2 },
    { day: "Thu", questions: 10, hours: 2.1 },
    { day: "Fri", questions: 18, hours: 4.0 },
    { day: "Sat", questions: 6, hours: 1.5 },
    { day: "Sun", questions: 9, hours: 2.0 },
  ];

  const recentAchievements = [
    { id: 1, name: "Problem Solver", description: "Solved 100 questions", icon: "🎯", date: "2 days ago" },
    { id: 2, name: "Study Streak", description: "7 days consecutive study", icon: "🔥", date: "5 days ago" },
    { id: 3, name: "Quick Learner", description: "Completed 10 topics", icon: "⚡", date: "1 week ago" },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold mb-2">
          <span className="text-gradient-red">Study Progress</span>
        </h1>
        <p className="text-muted-foreground">
          Track your learning journey and celebrate your achievements.
        </p>
      </div>

      {/* Time Period Selector */}
      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <Calendar className="w-5 h-5 text-muted-foreground" />
          <span className="text-sm font-medium">Time Period:</span>
        </div>
        <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
          <SelectTrigger className="w-40 bg-muted border-border">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {periods.map((period) => (
              <SelectItem key={period.value} value={period.value}>
                {period.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center">
                <Target className="text-blue-400 w-6 h-6" />
              </div>
              <Badge variant="secondary" className="bg-green-500/20 text-green-400">
                +15%
              </Badge>
            </div>
            <h3 className="text-2xl font-bold mb-1">{stats?.totalQuestions || 0}</h3>
            <p className="text-muted-foreground text-sm">Total Questions</p>
            <div className="mt-2">
              <Progress value={85} className="h-2" />
              <p className="text-xs text-muted-foreground mt-1">85% of weekly goal</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center">
                <Clock className="text-green-400 w-6 h-6" />
              </div>
              <Badge variant="secondary" className="bg-green-500/20 text-green-400">
                +2.5h
              </Badge>
            </div>
            <h3 className="text-2xl font-bold mb-1">{((stats?.totalStudyTime || 0) / 60).toFixed(1)}h</h3>
            <p className="text-muted-foreground text-sm">Study Time</p>
            <div className="mt-2">
              <Progress value={72} className="h-2" />
              <p className="text-xs text-muted-foreground mt-1">72% of weekly target</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center">
                <TrendingUp className="text-purple-400 w-6 h-6" />
              </div>
              <Badge variant="secondary" className="bg-green-500/20 text-green-400">
                +5%
              </Badge>
            </div>
            <h3 className="text-2xl font-bold mb-1">{stats?.averageAccuracy || 0}%</h3>
            <p className="text-muted-foreground text-sm">Accuracy Rate</p>
            <div className="mt-2">
              <Progress value={stats?.averageAccuracy || 0} className="h-2" />
              <p className="text-xs text-muted-foreground mt-1">Above average</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-orange-500/20 rounded-xl flex items-center justify-center">
                <Trophy className="text-orange-400 w-6 h-6" />
              </div>
              <Badge variant="secondary" className="bg-green-500/20 text-green-400">
                +3
              </Badge>
            </div>
            <h3 className="text-2xl font-bold mb-1">{stats?.streak || 0}</h3>
            <p className="text-muted-foreground text-sm">Day Streak</p>
            <div className="mt-2">
              <Progress value={Math.min((stats?.streak || 0) * 10, 100)} className="h-2" />
              <p className="text-xs text-muted-foreground mt-1">Keep it up!</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Weekly Activity Chart */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <TrendingUp className="w-5 h-5 text-primary" />
              <span>Weekly Activity</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {weeklyData.map((day, index) => (
                <div key={day.day} className="flex items-center space-x-4">
                  <div className="w-12 text-sm font-medium text-muted-foreground">
                    {day.day}
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between text-sm mb-1">
                      <span>{day.questions} questions</span>
                      <span className="text-muted-foreground">{day.hours}h</span>
                    </div>
                    <Progress value={(day.questions / 20) * 100} className="h-2" />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Subject Progress */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <BookOpen className="w-5 h-5 text-primary" />
              <span>Subject Mastery</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {subjects.map((subject) => (
                <div key={subject.name}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <subject.icon className={`w-4 h-4 ${subject.color}`} />
                      <span className="font-medium">{subject.name}</span>
                    </div>
                    <span className={`text-sm font-medium ${subject.color}`}>
                      {subject.progress}%
                    </span>
                  </div>
                  <Progress value={subject.progress} className="h-2" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent Achievements */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Trophy className="w-5 h-5 text-primary" />
              <span>Recent Achievements</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentAchievements.map((achievement) => (
                <div key={achievement.id} className="flex items-center space-x-3 p-3 bg-muted rounded-lg">
                  <div className="text-2xl">{achievement.icon}</div>
                  <div className="flex-1">
                    <h4 className="font-medium">{achievement.name}</h4>
                    <p className="text-sm text-muted-foreground">{achievement.description}</p>
                  </div>
                  <span className="text-xs text-muted-foreground">{achievement.date}</span>
                </div>
              ))}
            </div>
            <Button variant="outline" className="w-full mt-4 border-border">
              View All Achievements
            </Button>
          </CardContent>
        </Card>

        {/* Study Goals */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Target className="w-5 h-5 text-primary" />
              <span>Study Goals</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="font-medium">Daily Questions</span>
                  <span className="text-sm text-muted-foreground">12/15</span>
                </div>
                <Progress value={80} className="h-2" />
                <p className="text-xs text-muted-foreground mt-1">3 more to reach daily goal</p>
              </div>

              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="font-medium">Weekly Study Time</span>
                  <span className="text-sm text-muted-foreground">18/25 hours</span>
                </div>
                <Progress value={72} className="h-2" />
                <p className="text-xs text-muted-foreground mt-1">7 hours left this week</p>
              </div>

              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="font-medium">Monthly Topics</span>
                  <span className="text-sm text-muted-foreground">8/12</span>
                </div>
                <Progress value={67} className="h-2" />
                <p className="text-xs text-muted-foreground mt-1">4 topics to complete</p>
              </div>
            </div>

            <Button className="w-full mt-6 bg-red-gradient hover:opacity-90">
              <Target className="w-4 h-4 mr-2" />
              Update Goals
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Learning Insights */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Brain className="w-5 h-5 text-primary" />
            <span>Learning Insights</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-3">
                <Clock className="w-8 h-8 text-blue-400" />
              </div>
              <h3 className="font-semibold mb-2">Peak Study Time</h3>
              <p className="text-2xl font-bold text-blue-400 mb-1">3-5 PM</p>
              <p className="text-sm text-muted-foreground">Most productive hours</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-3">
                <Target className="w-8 h-8 text-green-400" />
              </div>
              <h3 className="font-semibold mb-2">Strongest Subject</h3>
              <p className="text-2xl font-bold text-green-400 mb-1">Mathematics</p>
              <p className="text-sm text-muted-foreground">92% accuracy rate</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-purple-500/20 rounded-full flex items-center justify-center mx-auto mb-3">
                <TrendingUp className="w-8 h-8 text-purple-400" />
              </div>
              <h3 className="font-semibold mb-2">Improvement Area</h3>
              <p className="text-2xl font-bold text-purple-400 mb-1">Chemistry</p>
              <p className="text-sm text-muted-foreground">Focus for next week</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
