import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Brain, Calculator, Camera, MicOff, GraduationCap, FlaskRound, TrendingUp, BookOpen, Clock, Trophy, Target, CheckCircle, Zap, Award, Calendar, Star, ChevronRight } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";
import ImageUpload from "@/components/image-upload";
import AchievementSystem from "@/components/achievement-system";

// Mock user ID for demo
const MOCK_USER_ID = 1;

export default function Dashboard() {
  const [question, setQuestion] = useState("");
  const [selectedSubject, setSelectedSubject] = useState("");
  const [showAchievements, setShowAchievements] = useState(false);
  const [, setLocation] = useLocation();

  const { data: stats } = useQuery({
    queryKey: [`/api/user/${MOCK_USER_ID}/stats`],
  });

  const { data: recentQuestions } = useQuery({
    queryKey: [`/api/user/${MOCK_USER_ID}/questions`],
  });

  const { data: formulas } = useQuery({
    queryKey: ["/api/formulas"],
  });

  const { data: flashcards } = useQuery({
    queryKey: [`/api/flashcards/user/${MOCK_USER_ID}`],
  });

  const { data: quizAttempts } = useQuery({
    queryKey: [`/api/quiz-attempts/user/${MOCK_USER_ID}`],
  });

  const popularFormulas = formulas?.slice(0, 3) || [];
  const recentFlashcards = (flashcards as any[])?.slice(0, 3) || [];
  const recentQuizzes = (quizAttempts as any[])?.slice(0, 3) || [];

  const subjects = [
    { value: "mathematics", label: "Mathematics", icon: Calculator, color: "text-blue-400" },
    { value: "physics", label: "Physics", icon: Zap, color: "text-purple-400" },
    { value: "chemistry", label: "Chemistry", icon: FlaskRound, color: "text-orange-400" },
    { value: "engineering", label: "Engineering", icon: BookOpen, color: "text-teal-400" },
  ];

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div>
        <h1 className="text-3xl font-bold mb-2">
          Welcome back, <span className="text-gradient-red">Student</span>!
        </h1>
        <p className="text-muted-foreground">
          Ready to learn something new today? Let's explore your personalized learning dashboard.
        </p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center">
                <CheckCircle className="text-blue-400 w-6 h-6" />
              </div>
              <span className="text-green-400 text-sm font-medium">+12%</span>
            </div>
            <h3 className="text-2xl font-bold mb-1">{stats?.totalQuestions || 0}</h3>
            <p className="text-muted-foreground text-sm">Questions Solved</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center">
                <Clock className="text-green-400 w-6 h-6" />
              </div>
              <span className="text-green-400 text-sm font-medium">+5hrs</span>
            </div>
            <h3 className="text-2xl font-bold mb-1">{((stats?.totalStudyTime || 0) / 60).toFixed(1)}h</h3>
            <p className="text-muted-foreground text-sm">Study Time</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center">
                <Trophy className="text-purple-400 w-6 h-6" />
              </div>
              <span className="text-green-400 text-sm font-medium">+2</span>
            </div>
            <h3 className="text-2xl font-bold mb-1">15</h3>
            <p className="text-muted-foreground text-sm">Achievements</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-red-500/20 rounded-xl flex items-center justify-center">
                <Target className="text-red-400 w-6 h-6" />
              </div>
              <span className="text-green-400 text-sm font-medium">92%</span>
            </div>
            <h3 className="text-2xl font-bold mb-1">{stats?.averageAccuracy || 0}%</h3>
            <p className="text-muted-foreground text-sm">Accuracy Rate</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Features Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Question Solver */}
        <Card className="bg-card border-border">
          <CardHeader className="border-b border-border">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-red-gradient rounded-xl flex items-center justify-center">
                <Brain className="text-white w-5 h-5" />
              </div>
              <div>
                <CardTitle>AI Question Solver</CardTitle>
                <p className="text-sm text-muted-foreground">Get instant solutions with step-by-step explanations</p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-4">
              <Textarea
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="Type your question here or upload an image..."
                className="min-h-[100px] bg-muted border-border"
              />

              <Select value={selectedSubject} onValueChange={setSelectedSubject}>
                <SelectTrigger className="bg-muted border-border">
                  <SelectValue placeholder="Select subject" />
                </SelectTrigger>
                <SelectContent>
                  {subjects.map((subject) => (
                    <SelectItem key={subject.value} value={subject.value}>
                      {subject.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <div className="flex items-center space-x-3">
                <Button className="flex-1 bg-red-gradient hover:opacity-90">
                  <Brain className="w-4 h-4 mr-2" />
                  Solve Question
                </Button>
                <ImageUpload onImageSelect={() => {}} />
                <Button variant="outline" size="icon" className="border-border">
                  <MicOff className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* AI Tutor */}
        <Card className="bg-card border-border">
          <CardHeader className="border-b border-border">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-green-500/20 rounded-xl flex items-center justify-center">
                <GraduationCap className="text-green-400 w-5 h-5" />
              </div>
              <div>
                <CardTitle>AI Personal Tutor</CardTitle>
                <p className="text-sm text-muted-foreground">Interactive learning with personalized guidance</p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-4">
              <Card className="bg-muted border-border">
                <CardContent className="p-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-green-gradient rounded-full flex items-center justify-center flex-shrink-0">
                      <Brain className="text-white w-4 h-4" />
                    </div>
                    <p className="text-sm text-muted-foreground">
                      What topic would you like to explore today? I can help you with Mathematics, Physics, Chemistry, or any technical subject!
                    </p>
                  </div>
                </CardContent>
              </Card>

              <div className="grid grid-cols-2 gap-3">
                {subjects.map((subject) => (
                  <Button
                    key={subject.value}
                    variant="outline"
                    className={`justify-start border-border hover:bg-muted ${subject.color}`}
                  >
                    <subject.icon className="w-4 h-4 mr-2" />
                    {subject.label}
                  </Button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Photo Scan & Formula Lab */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Photo Scan */}
        <Card className="bg-card border-border">
          <CardHeader className="border-b border-border">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-500/20 rounded-xl flex items-center justify-center">
                <Camera className="text-blue-400 w-5 h-5" />
              </div>
              <div>
                <CardTitle>Smart Photo Scanner</CardTitle>
                <p className="text-sm text-muted-foreground">Upload exam papers and get instant analysis</p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-6">
            <ImageUpload 
              onImageSelect={() => {}}
              className="border-2 border-dashed border-border rounded-xl p-8 text-center hover:border-blue-400 transition-colors"
            />
            <div className="mt-4 space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Supported formats:</span>
                <span>JPG, PNG, PDF</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Max file size:</span>
                <span>10MB</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Formula Lab */}
        <Card className="bg-card border-border">
          <CardHeader className="border-b border-border">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-purple-500/20 rounded-xl flex items-center justify-center">
                <FlaskRound className="text-purple-400 w-5 h-5" />
              </div>
              <div>
                <CardTitle>Formula Laboratory</CardTitle>
                <p className="text-sm text-muted-foreground">Interactive formula explorer with examples</p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-4">
              {popularFormulas.map((formula: any) => (
                <Card key={formula.id} className="bg-muted border-border hover:bg-muted/80 transition-colors cursor-pointer">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">{formula.name}</h4>
                        <p className="text-sm text-muted-foreground">{formula.formula}</p>
                      </div>
                      <ChevronRight className="text-purple-400 w-4 h-4" />
                    </div>
                  </CardContent>
                </Card>
              ))}

              <Button variant="outline" className="w-full border-border hover:bg-muted">
                <FlaskRound className="w-4 h-4 mr-2" />
                Browse All Formulas
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Study Progress & Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Study Progress */}
        <div className="lg:col-span-2">
          <Card className="bg-card border-border">
            <CardHeader className="border-b border-border">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-green-500/20 rounded-xl flex items-center justify-center">
                    <TrendingUp className="text-green-400 w-5 h-5" />
                  </div>
                  <CardTitle>Study Progress</CardTitle>
                </div>
                <Select defaultValue="7days">
                  <SelectTrigger className="w-32 bg-muted border-border">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7days">Last 7 days</SelectItem>
                    <SelectItem value="30days">Last 30 days</SelectItem>
                    <SelectItem value="3months">Last 3 months</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent className="p-6">
              <div className="bg-gradient-to-r from-red-500/20 to-purple-500/20 rounded-xl p-6 mb-6">
                <div className="grid grid-cols-3 gap-6 text-center">
                  <div>
                    <h3 className="text-2xl font-bold mb-1">85%</h3>
                    <p className="text-sm text-muted-foreground">Daily Goal</p>
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold mb-1">{stats?.streak || 0}</h3>
                    <p className="text-sm text-muted-foreground">Day Streak</p>
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold mb-1">47</h3>
                    <p className="text-sm text-muted-foreground">Topics Mastered</p>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Mathematics</span>
                    <span className="text-green-400">92%</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div className="bg-green-gradient h-2 rounded-full" style={{ width: '92%' }}></div>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Physics</span>
                    <span className="text-blue-400">78%</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div className="bg-blue-gradient h-2 rounded-full" style={{ width: '78%' }}></div>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Chemistry</span>
                    <span className="text-purple-400">65%</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div className="bg-purple-gradient h-2 rounded-full" style={{ width: '65%' }}></div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity */}
        <Card className="bg-card border-border">
          <CardHeader className="border-b border-border">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-orange-500/20 rounded-xl flex items-center justify-center">
                <Clock className="text-orange-400 w-5 h-5" />
              </div>
              <CardTitle>Recent Activity</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-4">
              {recentQuestions?.slice(0, 4).map((question, index) => (
                <div key={question.id} className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-green-500/20 rounded-full flex items-center justify-center flex-shrink-0">
                    <CheckCircle className="text-green-400 w-4 h-4" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm">{question.content.slice(0, 50)}...</p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(question.createdAt!).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              )) || (
                <div className="text-center text-muted-foreground">
                  No recent activity
                </div>
              )}

              <Button variant="ghost" className="w-full mt-4 text-muted-foreground hover:text-foreground">
                View All Activity →
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* New Features Quick Access */}
      <div className="space-y-6">
        <h2 className="text-2xl font-bold">
          <span className="text-gradient-red">Enhanced Learning Tools</span>
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Flashcards */}
          <Card className="bg-card border-border hover:bg-muted/50 transition-colors cursor-pointer"
                onClick={() => setLocation('/flashcards')}>
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-orange-500/20 rounded-xl flex items-center justify-center">
                  <BookOpen className="text-orange-400 w-6 h-6" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold">Smart Flashcards</h3>
                  <p className="text-sm text-muted-foreground">Create and study with AI-powered flashcards</p>
                  <div className="flex items-center mt-2 text-sm">
                    <span className="text-orange-400 font-medium">{recentFlashcards.length} cards</span>
                    <ChevronRight className="w-4 h-4 ml-auto text-muted-foreground" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quiz Center */}
          <Card className="bg-card border-border hover:bg-muted/50 transition-colors cursor-pointer"
                onClick={() => setLocation('/quizzes')}>
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center">
                  <Zap className="text-blue-400 w-6 h-6" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold">Quiz Center</h3>
                  <p className="text-sm text-muted-foreground">Test knowledge with interactive quizzes</p>
                  <div className="flex items-center mt-2 text-sm">
                    <span className="text-blue-400 font-medium">{recentQuizzes.length} attempts</span>
                    <ChevronRight className="w-4 h-4 ml-auto text-muted-foreground" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Study Planner */}
          <Card className="bg-card border-border hover:bg-muted/50 transition-colors cursor-pointer"
                onClick={() => setLocation('/study-planner')}>
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center">
                  <Calendar className="text-green-400 w-6 h-6" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold">Study Planner</h3>
                  <p className="text-sm text-muted-foreground">Organize learning with smart scheduling</p>
                  <div className="flex items-center mt-2 text-sm">
                    <span className="text-green-400 font-medium">2 active plans</span>
                    <ChevronRight className="w-4 h-4 ml-auto text-muted-foreground" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Achievement System Toggle */}
      <Card className="bg-card border-border">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-yellow-500/20 rounded-xl flex items-center justify-center">
                <Trophy className="text-yellow-400 w-5 h-5" />
              </div>
              <div>
                <CardTitle>Achievement System</CardTitle>
                <p className="text-sm text-muted-foreground">Track progress and earn rewards</p>
              </div>
            </div>
            <Button
              variant="outline"
              onClick={() => setShowAchievements(!showAchievements)}
              className="border-border"
            >
              {showAchievements ? 'Hide' : 'Show'} Achievements
            </Button>
          </div>
        </CardHeader>
        {showAchievements && (
          <CardContent className="pt-0">
            <AchievementSystem />
          </CardContent>
        )}
      </Card>
    </div>
  );
}
