import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FlaskRound, Search, BookOpen, Calculator, Zap, Atom, Code, Heart } from "lucide-react";
import type { Formula } from "@shared/schema";

export default function Formulas() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedSubject, setSelectedSubject] = useState("all");
  const [selectedFormula, setSelectedFormula] = useState<Formula | null>(null);

  const { data: formulas = [], isLoading } = useQuery({
    queryKey: ["/api/formulas"],
  });

  const subjects = [
    { value: "all", label: "All Subjects", icon: BookOpen },
    { value: "Mathematics", label: "Mathematics", icon: Calculator },
    { value: "Physics", label: "Physics", icon: Zap },
    { value: "Chemistry", label: "Chemistry", icon: Atom },
    { value: "Engineering", label: "Engineering", icon: Code },
    { value: "Biology", label: "Biology", icon: Heart },
  ];

  const filteredFormulas = formulas.filter((formula: Formula) => {
    const matchesSearch = formula.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         formula.formula.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSubject = selectedSubject === "all" || formula.subject === selectedSubject;
    return matchesSearch && matchesSubject;
  });

  const groupedFormulas = filteredFormulas.reduce((acc: Record<string, Formula[]>, formula: Formula) => {
    if (!acc[formula.subject]) {
      acc[formula.subject] = [];
    }
    acc[formula.subject].push(formula);
    return acc;
  }, {});

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "basic": return "text-green-400 bg-green-500/20";
      case "intermediate": return "text-yellow-400 bg-yellow-500/20";
      case "advanced": return "text-red-400 bg-red-500/20";
      default: return "text-gray-400 bg-gray-500/20";
    }
  };

  const getSubjectIcon = (subject: string) => {
    const subjectData = subjects.find(s => s.label === subject);
    return subjectData?.icon || BookOpen;
  };

  if (isLoading) {
    return (
      <div className="max-w-6xl mx-auto space-y-8">
        <div>
          <h1 className="text-3xl font-bold mb-2">
            <span className="text-gradient-red">Formula Laboratory</span>
          </h1>
          <p className="text-muted-foreground">Loading formulas...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold mb-2">
          <span className="text-gradient-red">Formula Laboratory</span>
        </h1>
        <p className="text-muted-foreground">
          Explore and master essential formulas across mathematics, physics, chemistry, and more.
        </p>
      </div>

      {/* Search and Filter */}
      <Card className="bg-card border-border">
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search formulas..."
                className="pl-10 bg-muted border-border"
              />
            </div>
            <Select value={selectedSubject} onValueChange={setSelectedSubject}>
              <SelectTrigger className="w-full sm:w-48 bg-muted border-border">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {subjects.map((subject) => (
                  <SelectItem key={subject.value} value={subject.value}>
                    <span className="flex items-center space-x-2">
                      <subject.icon className="w-4 h-4" />
                      <span>{subject.label}</span>
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Formula List */}
        <div className="lg:col-span-2">
          <Tabs value={selectedSubject === "all" ? "all" : selectedSubject} className="space-y-6">
            <TabsList className="grid w-full grid-cols-3 lg:grid-cols-6 bg-muted">
              <TabsTrigger value="all" className="text-xs">All</TabsTrigger>
              {subjects.slice(1).map((subject) => (
                <TabsTrigger 
                  key={subject.value} 
                  value={subject.value}
                  className="text-xs"
                  onClick={() => setSelectedSubject(subject.value)}
                >
                  {subject.label.substring(0, 4)}
                </TabsTrigger>
              ))}
            </TabsList>

            <TabsContent value={selectedSubject} className="space-y-6">
              {Object.keys(groupedFormulas).length === 0 ? (
                <Card className="bg-card border-border">
                  <CardContent className="p-8 text-center">
                    <FlaskRound className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-medium mb-2">No Formulas Found</h3>
                    <p className="text-muted-foreground">
                      Try adjusting your search terms or subject filter.
                    </p>
                  </CardContent>
                </Card>
              ) : (
                Object.entries(groupedFormulas).map(([subject, subjectFormulas]) => (
                  <div key={subject}>
                    <div className="flex items-center space-x-2 mb-4">
                      {(() => {
                        const IconComponent = getSubjectIcon(subject);
                        return <IconComponent className="w-5 h-5 text-primary" />;
                      })()}
                      <h2 className="text-xl font-semibold">{subject}</h2>
                      <Badge variant="secondary" className="bg-muted">
                        {subjectFormulas.length} formulas
                      </Badge>
                    </div>
                    
                    <div className="grid gap-4">
                      {subjectFormulas.map((formula) => (
                        <Card
                          key={formula.id}
                          className="bg-card border-border hover:bg-muted/50 transition-colors cursor-pointer"
                          onClick={() => setSelectedFormula(formula)}
                        >
                          <CardContent className="p-4">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <div className="flex items-center space-x-2 mb-2">
                                  <h3 className="font-medium">{formula.name}</h3>
                                  {formula.difficulty && (
                                    <Badge className={getDifficultyColor(formula.difficulty)}>
                                      {formula.difficulty}
                                    </Badge>
                                  )}
                                </div>
                                <div className="bg-muted rounded-lg p-3 mb-2 font-mono text-sm">
                                  {formula.formula}
                                </div>
                                {formula.description && (
                                  <p className="text-sm text-muted-foreground">
                                    {formula.description}
                                  </p>
                                )}
                              </div>
                              <Button variant="ghost" size="sm">
                                →
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                ))
              )}
            </TabsContent>
          </Tabs>
        </div>

        {/* Formula Details */}
        <Card className="bg-card border-border h-fit">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <FlaskRound className="w-5 h-5 text-purple-400" />
              <span>Formula Details</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {selectedFormula ? (
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold mb-2">{selectedFormula.name}</h3>
                  <div className="flex items-center space-x-2 mb-3">
                    <Badge variant="outline" className="border-border">
                      {selectedFormula.subject}
                    </Badge>
                    {selectedFormula.difficulty && (
                      <Badge className={getDifficultyColor(selectedFormula.difficulty)}>
                        {selectedFormula.difficulty}
                      </Badge>
                    )}
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Formula:</h4>
                  <div className="bg-muted rounded-lg p-4 font-mono text-center text-lg">
                    {selectedFormula.formula}
                  </div>
                </div>

                {selectedFormula.description && (
                  <div>
                    <h4 className="font-medium mb-2">Description:</h4>
                    <p className="text-sm text-muted-foreground">
                      {selectedFormula.description}
                    </p>
                  </div>
                )}

                {selectedFormula.examples && Array.isArray(selectedFormula.examples) && selectedFormula.examples.length > 0 && (
                  <div>
                    <h4 className="font-medium mb-2">Examples:</h4>
                    <div className="space-y-2">
                      {selectedFormula.examples.map((example: any, index: number) => (
                        <div key={index} className="bg-muted rounded-lg p-3">
                          <div className="text-sm">
                            {typeof example === 'object' ? (
                              <>
                                {example.equation && <p><strong>Equation:</strong> {example.equation}</p>}
                                {example.problem && <p><strong>Problem:</strong> {example.problem}</p>}
                                {example.solution && <p><strong>Solution:</strong> {example.solution}</p>}
                              </>
                            ) : (
                              <p>{example}</p>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <Button className="w-full bg-red-gradient hover:opacity-90">
                  <Calculator className="w-4 h-4 mr-2" />
                  Practice with This Formula
                </Button>
              </div>
            ) : (
              <div className="text-center py-8">
                <FlaskRound className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">
                  Select a formula from the list to view detailed information and examples.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {subjects.slice(1).map((subject) => {
          const count = formulas.filter((f: Formula) => f.subject === subject.label).length;
          return (
            <Card key={subject.value} className="bg-card border-border">
              <CardContent className="p-4 text-center">
                <subject.icon className="w-8 h-8 text-primary mx-auto mb-2" />
                <h3 className="font-medium text-sm">{subject.label}</h3>
                <p className="text-2xl font-bold text-primary">{count}</p>
                <p className="text-xs text-muted-foreground">formulas</p>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
