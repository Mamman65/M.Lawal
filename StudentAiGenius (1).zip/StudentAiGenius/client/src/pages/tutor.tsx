import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { GraduationCap, Brain, BookOpen, ArrowRight, Send, Lightbulb } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import AiChat from "@/components/ai-chat";

interface TutorResponse {
  response: string;
  suggestedTopics: string[];
  difficulty: string;
  nextSteps: string[];
}

interface ChatMessage {
  id: string;
  type: 'user' | 'tutor';
  content: string;
  timestamp: Date;
  metadata?: {
    suggestedTopics?: string[];
    nextSteps?: string[];
    difficulty?: string;
  };
}

export default function Tutor() {
  const [selectedSubject, setSelectedSubject] = useState("");
  const [selectedDifficulty, setSelectedDifficulty] = useState("intermediate");
  const [currentMessage, setCurrentMessage] = useState("");
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [isTyping, setIsTyping] = useState(false);

  const { toast } = useToast();

  const tutorMutation = useMutation({
    mutationFn: async ({ topic, message, difficulty }: { topic: string; message: string; difficulty: string }) => {
      const response = await apiRequest("POST", "/api/tutor", { topic, message, difficulty });
      return response.json();
    },
    onSuccess: (data: TutorResponse) => {
      const tutorMessage: ChatMessage = {
        id: Date.now().toString() + '_tutor',
        type: 'tutor',
        content: data.response,
        timestamp: new Date(),
        metadata: {
          suggestedTopics: data.suggestedTopics,
          nextSteps: data.nextSteps,
          difficulty: data.difficulty
        }
      };
      
      setChatHistory(prev => [...prev, tutorMessage]);
      setIsTyping(false);
    },
    onError: (error) => {
      setIsTyping(false);
      toast({
        title: "Error",
        description: "Failed to get response from tutor. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = () => {
    if (!currentMessage.trim() || !selectedSubject) {
      toast({
        title: "Missing Information",
        description: "Please select a subject and enter a message.",
        variant: "destructive",
      });
      return;
    }

    // Add user message
    const userMessage: ChatMessage = {
      id: Date.now().toString() + '_user',
      type: 'user',
      content: currentMessage,
      timestamp: new Date()
    };

    setChatHistory(prev => [...prev, userMessage]);
    setIsTyping(true);

    // Send to AI tutor
    tutorMutation.mutate({
      topic: selectedSubject,
      message: currentMessage,
      difficulty: selectedDifficulty
    });

    setCurrentMessage("");
  };

  const handleQuickQuestion = (question: string) => {
    setCurrentMessage(question);
  };

  const handleSuggestedTopic = (topic: string) => {
    setCurrentMessage(`Can you teach me about ${topic}?`);
  };

  const subjects = [
    { value: "mathematics", label: "Mathematics", icon: "📐", color: "text-blue-400" },
    { value: "physics", label: "Physics", icon: "⚛️", color: "text-purple-400" },
    { value: "chemistry", label: "Chemistry", icon: "🧪", color: "text-orange-400" },
    { value: "biology", label: "Biology", icon: "🧬", color: "text-green-400" },
    { value: "computer-science", label: "Computer Science", icon: "💻", color: "text-cyan-400" },
    { value: "engineering", label: "Engineering", icon: "⚙️", color: "text-yellow-400" },
  ];

  const difficulties = [
    { value: "beginner", label: "Beginner", description: "New to the topic" },
    { value: "intermediate", label: "Intermediate", description: "Some experience" },
    { value: "advanced", label: "Advanced", description: "Deep understanding" },
  ];

  const quickQuestions = [
    "Explain the concept in simple terms",
    "Show me step-by-step examples",
    "What are common mistakes to avoid?",
    "How does this apply in real life?",
    "What should I study next?",
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold mb-2">
          <span className="text-gradient-red">AI Personal Tutor</span>
        </h1>
        <p className="text-muted-foreground">
          Get personalized learning assistance with interactive AI tutoring for any subject.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Settings Panel */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <GraduationCap className="w-5 h-5 text-primary" />
              <span>Learning Settings</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Subject</label>
              <Select value={selectedSubject} onValueChange={setSelectedSubject}>
                <SelectTrigger className="bg-muted border-border">
                  <SelectValue placeholder="Choose subject" />
                </SelectTrigger>
                <SelectContent>
                  {subjects.map((subject) => (
                    <SelectItem key={subject.value} value={subject.value}>
                      <span className="flex items-center space-x-2">
                        <span>{subject.icon}</span>
                        <span>{subject.label}</span>
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Difficulty Level</label>
              <Select value={selectedDifficulty} onValueChange={setSelectedDifficulty}>
                <SelectTrigger className="bg-muted border-border">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {difficulties.map((difficulty) => (
                    <SelectItem key={difficulty.value} value={difficulty.value}>
                      <div>
                        <div className="font-medium">{difficulty.label}</div>
                        <div className="text-xs text-muted-foreground">{difficulty.description}</div>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Quick Questions */}
            <div>
              <label className="text-sm font-medium mb-2 block">Quick Questions</label>
              <div className="space-y-2">
                {quickQuestions.map((question, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    className="w-full justify-start text-left border-border hover:bg-muted text-xs"
                    onClick={() => handleQuickQuestion(question)}
                  >
                    {question}
                  </Button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Chat Interface */}
        <div className="lg:col-span-2">
          <Card className="bg-card border-border h-[600px] flex flex-col">
            <CardHeader className="border-b border-border">
              <CardTitle className="flex items-center space-x-2">
                <Brain className="w-5 h-5 text-green-400" />
                <span>Chat with AI Tutor</span>
                {selectedSubject && (
                  <Badge variant="secondary" className="ml-2">
                    {subjects.find(s => s.value === selectedSubject)?.label}
                  </Badge>
                )}
              </CardTitle>
            </CardHeader>

            {/* Chat Messages */}
            <CardContent className="flex-1 overflow-y-auto p-4">
              {chatHistory.length === 0 ? (
                <div className="flex items-center justify-center h-full">
                  <div className="text-center">
                    <BookOpen className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-medium mb-2">Ready to Learn!</h3>
                    <p className="text-muted-foreground text-sm">
                      Select a subject and ask me anything. I'm here to help you understand complex topics.
                    </p>
                  </div>
                </div>
              ) : (
                <AiChat messages={chatHistory} isTyping={isTyping} />
              )}
            </CardContent>

            {/* Message Input */}
            <div className="border-t border-border p-4">
              <div className="flex space-x-2">
                <Input
                  value={currentMessage}
                  onChange={(e) => setCurrentMessage(e.target.value)}
                  placeholder="Ask me anything about the subject..."
                  className="bg-muted border-border"
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  disabled={!selectedSubject || tutorMutation.isPending}
                />
                <Button
                  onClick={handleSendMessage}
                  disabled={!selectedSubject || !currentMessage.trim() || tutorMutation.isPending}
                  className="bg-red-gradient hover:opacity-90"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>

              {/* Show suggested topics from last tutor response */}
              {chatHistory.length > 0 && chatHistory[chatHistory.length - 1]?.metadata?.suggestedTopics && (
                <div className="mt-3">
                  <label className="text-xs text-muted-foreground mb-2 block">Suggested topics:</label>
                  <div className="flex flex-wrap gap-2">
                    {chatHistory[chatHistory.length - 1].metadata!.suggestedTopics!.map((topic, index) => (
                      <Button
                        key={index}
                        variant="outline"
                        size="sm"
                        className="text-xs border-border hover:bg-muted"
                        onClick={() => handleSuggestedTopic(topic)}
                      >
                        <Lightbulb className="w-3 h-3 mr-1" />
                        {topic}
                      </Button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </Card>
        </div>
      </div>

      {/* Learning Tips */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle>Maximize Your Learning</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-3">
                <BookOpen className="w-6 h-6 text-blue-400" />
              </div>
              <h3 className="font-medium mb-2">Ask Specific Questions</h3>
              <p className="text-sm text-muted-foreground">
                Be specific about what you want to learn for better explanations.
              </p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-3">
                <Lightbulb className="w-6 h-6 text-green-400" />
              </div>
              <h3 className="font-medium mb-2">Practice Examples</h3>
              <p className="text-sm text-muted-foreground">
                Ask for examples and practice problems to reinforce learning.
              </p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-purple-500/20 rounded-full flex items-center justify-center mx-auto mb-3">
                <ArrowRight className="w-6 h-6 text-purple-400" />
              </div>
              <h3 className="font-medium mb-2">Build Progressively</h3>
              <p className="text-sm text-muted-foreground">
                Start with basics and gradually move to advanced concepts.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
