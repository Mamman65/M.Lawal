import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Clock, Trophy, Plus, Brain, Play, ChevronRight, Target, CheckCircle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertQuizSchema } from "@shared/schema";
import type { Quiz, QuizAttempt } from "@shared/schema";

const MOCK_USER_ID = 1;

interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation?: string;
}

export default function Quizzes() {
  const [selectedSubject, setSelectedSubject] = useState("");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [activeQuiz, setActiveQuiz] = useState<Quiz | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [timeRemaining, setTimeRemaining] = useState<number | null>(null);
  const [showResults, setShowResults] = useState(false);
  const [quizResults, setQuizResults] = useState<any>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: quizzes = [], isLoading } = useQuery({
    queryKey: [`/api/quizzes/user/${MOCK_USER_ID}`],
  });

  const { data: attempts = [] } = useQuery({
    queryKey: [`/api/quiz-attempts/user/${MOCK_USER_ID}`],
  });

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/quizzes", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/quizzes/user/${MOCK_USER_ID}`] });
      setIsCreateDialogOpen(false);
      toast({
        title: "Quiz Created!",
        description: "Your quiz has been created and is ready to take.",
      });
    },
  });

  const submitQuizMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/quiz-attempts", data);
      return response.json();
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: [`/api/quiz-attempts/user/${MOCK_USER_ID}`] });
      setQuizResults(result);
      setShowResults(true);
      toast({
        title: "Quiz Completed!",
        description: `You scored ${result.score}%`,
      });
    },
  });

  const form = useForm({
    resolver: zodResolver(insertQuizSchema),
    defaultValues: {
      title: "",
      subject: "",
      questions: [],
      timeLimit: 30,
      difficulty: "intermediate",
    },
  });

  const subjects = [
    { value: "Mathematics", label: "Mathematics" },
    { value: "Physics", label: "Physics" },
    { value: "Chemistry", label: "Chemistry" },
    { value: "Biology", label: "Biology" },
    { value: "Computer Science", label: "Computer Science" },
  ];

  const filteredQuizzes = selectedSubject 
    ? quizzes.filter((quiz: Quiz) => quiz.subject === selectedSubject)
    : quizzes;

  const startQuiz = (quiz: Quiz) => {
    setActiveQuiz(quiz);
    setCurrentQuestionIndex(0);
    setSelectedAnswers({});
    setShowResults(false);
    
    if (quiz.timeLimit) {
      setTimeRemaining(quiz.timeLimit * 60); // Convert minutes to seconds
    }
  };

  const selectAnswer = (questionId: string, answerIndex: number) => {
    setSelectedAnswers(prev => ({
      ...prev,
      [questionId]: answerIndex
    }));
  };

  const nextQuestion = () => {
    if (activeQuiz && currentQuestionIndex < activeQuiz.questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    }
  };

  const prevQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    }
  };

  const submitQuiz = () => {
    if (!activeQuiz) return;

    const questions = activeQuiz.questions as QuizQuestion[];
    let correctAnswers = 0;
    
    questions.forEach((q) => {
      if (selectedAnswers[q.id] === q.correctAnswer) {
        correctAnswers++;
      }
    });

    const score = Math.round((correctAnswers / questions.length) * 100);
    const timeSpent = activeQuiz.timeLimit ? (activeQuiz.timeLimit * 60) - (timeRemaining || 0) : 0;

    submitQuizMutation.mutate({
      quizId: activeQuiz.id,
      answers: selectedAnswers,
      score,
      timeSpent,
      userId: MOCK_USER_ID,
    });
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "easy": return "text-green-400 bg-green-500/20";
      case "intermediate": return "text-yellow-400 bg-yellow-500/20";
      case "hard": return "text-red-400 bg-red-500/20";
      default: return "text-gray-400 bg-gray-500/20";
    }
  };

  const currentQuestion = activeQuiz?.questions?.[currentQuestionIndex] as QuizQuestion;

  if (activeQuiz && !showResults) {
    return (
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Quiz Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">{activeQuiz.title}</h1>
            <p className="text-muted-foreground">{activeQuiz.subject}</p>
          </div>
          <div className="flex items-center space-x-4">
            {timeRemaining !== null && (
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4" />
                <span>{Math.floor(timeRemaining / 60)}:{(timeRemaining % 60).toString().padStart(2, '0')}</span>
              </div>
            )}
            <Badge variant="outline">
              {currentQuestionIndex + 1} of {activeQuiz.questions.length}
            </Badge>
          </div>
        </div>

        {/* Progress */}
        <Progress 
          value={((currentQuestionIndex + 1) / activeQuiz.questions.length) * 100} 
          className="h-2"
        />

        {/* Question */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle>Question {currentQuestionIndex + 1}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <p className="text-lg">{currentQuestion?.question}</p>
            
            <RadioGroup
              value={selectedAnswers[currentQuestion?.id]?.toString()}
              onValueChange={(value) => selectAnswer(currentQuestion?.id, parseInt(value))}
            >
              {currentQuestion?.options.map((option, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <RadioGroupItem value={index.toString()} id={`option-${index}`} />
                  <Label htmlFor={`option-${index}`} className="cursor-pointer flex-1">
                    {option}
                  </Label>
                </div>
              ))}
            </RadioGroup>

            <div className="flex justify-between">
              <Button
                variant="outline"
                onClick={prevQuestion}
                disabled={currentQuestionIndex === 0}
              >
                Previous
              </Button>
              
              {currentQuestionIndex === activeQuiz.questions.length - 1 ? (
                <Button
                  onClick={submitQuiz}
                  disabled={Object.keys(selectedAnswers).length < activeQuiz.questions.length}
                  className="bg-green-gradient hover:opacity-90"
                >
                  Submit Quiz
                </Button>
              ) : (
                <Button
                  onClick={nextQuestion}
                  disabled={!selectedAnswers[currentQuestion?.id]}
                >
                  Next
                  <ChevronRight className="w-4 h-4 ml-2" />
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (showResults && quizResults) {
    return (
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="text-center">
          <Trophy className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
          <h1 className="text-3xl font-bold mb-2">Quiz Complete!</h1>
          <p className="text-muted-foreground">Here's how you performed</p>
        </div>

        <Card className="bg-card border-border">
          <CardContent className="p-8 space-y-6">
            <div className="text-center">
              <div className="text-4xl font-bold text-gradient-red mb-2">
                {quizResults.score}%
              </div>
              <p className="text-muted-foreground">Final Score</p>
            </div>

            <div className="grid grid-cols-2 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-green-400">
                  {Math.round((quizResults.score / 100) * activeQuiz?.questions.length)}
                </div>
                <p className="text-sm text-muted-foreground">Correct Answers</p>
              </div>
              <div>
                <div className="text-2xl font-bold text-blue-400">
                  {Math.floor(quizResults.timeSpent / 60)}m {quizResults.timeSpent % 60}s
                </div>
                <p className="text-sm text-muted-foreground">Time Taken</p>
              </div>
            </div>

            <Button
              onClick={() => {
                setActiveQuiz(null);
                setShowResults(false);
              }}
              className="w-full bg-red-gradient hover:opacity-90"
            >
              Back to Quizzes
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold mb-2">
          <span className="text-gradient-red">Quiz Center</span>
        </h1>
        <p className="text-muted-foreground">
          Create custom quizzes and test your knowledge across different subjects.
        </p>
      </div>

      {/* Controls */}
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <Select value={selectedSubject} onValueChange={setSelectedSubject}>
          <SelectTrigger className="w-48 bg-muted border-border">
            <SelectValue placeholder="All subjects" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">All Subjects</SelectItem>
            {subjects.map((subject) => (
              <SelectItem key={subject.value} value={subject.value}>
                {subject.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-red-gradient hover:opacity-90">
              <Plus className="w-4 h-4 mr-2" />
              Create Quiz
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create New Quiz</DialogTitle>
            </DialogHeader>
            <div className="text-center py-8">
              <Brain className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">
                AI-powered quiz creation coming soon! For now, practice with our sample quizzes.
              </p>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Sample Quizzes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[
          {
            id: 1,
            title: "Algebra Fundamentals",
            subject: "Mathematics",
            difficulty: "easy",
            timeLimit: 15,
            questions: [
              {
                id: "q1",
                question: "What is the value of x in the equation: 2x + 5 = 11?",
                options: ["2", "3", "4", "5"],
                correctAnswer: 1,
                explanation: "Solving: 2x + 5 = 11, so 2x = 6, therefore x = 3"
              },
              {
                id: "q2",
                question: "Simplify: 3x + 2x - x",
                options: ["4x", "5x", "6x", "2x"],
                correctAnswer: 0,
                explanation: "3x + 2x - x = 5x - x = 4x"
              },
              {
                id: "q3",
                question: "What is the slope of the line y = 2x + 3?",
                options: ["2", "3", "1", "0"],
                correctAnswer: 0,
                explanation: "In the form y = mx + b, m is the slope, so the slope is 2"
              }
            ]
          },
          {
            id: 2,
            title: "Basic Physics",
            subject: "Physics",
            difficulty: "intermediate",
            timeLimit: 20,
            questions: [
              {
                id: "q1",
                question: "What is the unit of force in the SI system?",
                options: ["Newton", "Joule", "Watt", "Pascal"],
                correctAnswer: 0,
                explanation: "The Newton (N) is the SI unit of force"
              },
              {
                id: "q2",
                question: "Which law states that F = ma?",
                options: ["First Law", "Second Law", "Third Law", "Zeroth Law"],
                correctAnswer: 1,
                explanation: "Newton's Second Law states that Force equals mass times acceleration"
              }
            ]
          },
          {
            id: 3,
            title: "Chemical Bonds",
            subject: "Chemistry",
            difficulty: "hard",
            timeLimit: 25,
            questions: [
              {
                id: "q1",
                question: "What type of bond forms between metals and non-metals?",
                options: ["Covalent", "Ionic", "Metallic", "Hydrogen"],
                correctAnswer: 1,
                explanation: "Ionic bonds form when electrons are transferred from metals to non-metals"
              }
            ]
          }
        ].map((quiz) => (
          <Card key={quiz.id} className="bg-card border-border hover:bg-muted/50 transition-colors">
            <CardHeader>
              <div className="flex items-center justify-between">
                <Badge variant="outline" className="border-border">
                  {quiz.subject}
                </Badge>
                <Badge className={getDifficultyColor(quiz.difficulty)}>
                  {quiz.difficulty}
                </Badge>
              </div>
              <CardTitle>{quiz.title}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between text-sm text-muted-foreground">
                <div className="flex items-center">
                  <Target className="w-4 h-4 mr-1" />
                  {quiz.questions.length} questions
                </div>
                <div className="flex items-center">
                  <Clock className="w-4 h-4 mr-1" />
                  {quiz.timeLimit} min
                </div>
              </div>
              
              <Button
                onClick={() => startQuiz(quiz as any)}
                className="w-full bg-blue-gradient hover:opacity-90"
              >
                <Play className="w-4 h-4 mr-2" />
                Start Quiz
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Recent Attempts */}
      {attempts.length > 0 && (
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle>Recent Quiz Attempts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {attempts.slice(0, 5).map((attempt: QuizAttempt) => (
                <div key={attempt.id} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="w-5 h-5 text-green-400" />
                    <div>
                      <p className="font-medium">Quiz #{attempt.quizId}</p>
                      <p className="text-sm text-muted-foreground">
                        Completed {new Date(attempt.completedAt!).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-lg">{attempt.score}%</p>
                    <p className="text-sm text-muted-foreground">
                      {Math.floor((attempt.timeSpent || 0) / 60)}m {(attempt.timeSpent || 0) % 60}s
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}