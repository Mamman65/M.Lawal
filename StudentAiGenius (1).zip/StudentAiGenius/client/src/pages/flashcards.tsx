import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { BookOpen, Plus, RotateCcw, ChevronLeft, ChevronRight, Brain, Trash2, Edit3, Clock } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertFlashcardSchema } from "@shared/schema";
import type { Flashcard } from "@shared/schema";

const MOCK_USER_ID = 1;

export default function Flashcards() {
  const [selectedSubject, setSelectedSubject] = useState("");
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [showAnswer, setShowAnswer] = useState(false);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [studyMode, setStudyMode] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: flashcards = [], isLoading } = useQuery({
    queryKey: [`/api/flashcards/user/${MOCK_USER_ID}`, selectedSubject],
  });

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/flashcards", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/flashcards/user/${MOCK_USER_ID}`] });
      setIsCreateDialogOpen(false);
      toast({
        title: "Flashcard Created!",
        description: "Your new flashcard has been added to your collection.",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/flashcards/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/flashcards/user/${MOCK_USER_ID}`] });
      toast({
        title: "Flashcard Deleted",
        description: "The flashcard has been removed from your collection.",
      });
    },
  });

  const form = useForm({
    resolver: zodResolver(insertFlashcardSchema),
    defaultValues: {
      subject: "",
      question: "",
      answer: "",
      difficulty: "intermediate",
      tags: [],
    },
  });

  const filteredCards = selectedSubject 
    ? flashcards.filter((card: Flashcard) => card.subject === selectedSubject)
    : flashcards;

  const currentCard = filteredCards[currentCardIndex];

  const subjects = [
    { value: "Mathematics", label: "Mathematics", color: "bg-blue-500" },
    { value: "Physics", label: "Physics", color: "bg-purple-500" },
    { value: "Chemistry", label: "Chemistry", color: "bg-orange-500" },
    { value: "Biology", label: "Biology", color: "bg-green-500" },
    { value: "Computer Science", label: "Computer Science", color: "bg-cyan-500" },
  ];

  const onSubmit = (data: any) => {
    createMutation.mutate({
      ...data,
      userId: MOCK_USER_ID,
    });
  };

  const nextCard = () => {
    setCurrentCardIndex((prev) => (prev + 1) % filteredCards.length);
    setShowAnswer(false);
  };

  const prevCard = () => {
    setCurrentCardIndex((prev) => (prev - 1 + filteredCards.length) % filteredCards.length);
    setShowAnswer(false);
  };

  const startStudyMode = () => {
    setStudyMode(true);
    setCurrentCardIndex(0);
    setShowAnswer(false);
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "easy": return "text-green-400 bg-green-500/20";
      case "intermediate": return "text-yellow-400 bg-yellow-500/20";
      case "hard": return "text-red-400 bg-red-500/20";
      default: return "text-gray-400 bg-gray-500/20";
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold mb-2">
          <span className="text-gradient-red">Smart Flashcards</span>
        </h1>
        <p className="text-muted-foreground">
          Create, organize, and study with AI-powered flashcards for better retention.
        </p>
      </div>

      {/* Controls */}
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div className="flex gap-4">
          <Select value={selectedSubject} onValueChange={setSelectedSubject}>
            <SelectTrigger className="w-48 bg-muted border-border">
              <SelectValue placeholder="All subjects" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">All Subjects</SelectItem>
              {subjects.map((subject) => (
                <SelectItem key={subject.value} value={subject.value}>
                  {subject.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {filteredCards.length > 0 && (
            <Button
              onClick={startStudyMode}
              className="bg-green-gradient hover:opacity-90"
            >
              <Brain className="w-4 h-4 mr-2" />
              Study Mode
            </Button>
          )}
        </div>

        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-red-gradient hover:opacity-90">
              <Plus className="w-4 h-4 mr-2" />
              Create Flashcard
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border">
            <DialogHeader>
              <DialogTitle>Create New Flashcard</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="subject"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Subject</FormLabel>
                      <FormControl>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <SelectTrigger className="bg-muted border-border">
                            <SelectValue placeholder="Select subject" />
                          </SelectTrigger>
                          <SelectContent>
                            {subjects.map((subject) => (
                              <SelectItem key={subject.value} value={subject.value}>
                                {subject.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </FormControl>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="question"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Question</FormLabel>
                      <FormControl>
                        <Textarea
                          {...field}
                          placeholder="Enter your question..."
                          className="bg-muted border-border"
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="answer"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Answer</FormLabel>
                      <FormControl>
                        <Textarea
                          {...field}
                          placeholder="Enter the answer..."
                          className="bg-muted border-border"
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="difficulty"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Difficulty</FormLabel>
                      <FormControl>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <SelectTrigger className="bg-muted border-border">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="easy">Easy</SelectItem>
                            <SelectItem value="intermediate">Intermediate</SelectItem>
                            <SelectItem value="hard">Hard</SelectItem>
                          </SelectContent>
                        </Select>
                      </FormControl>
                    </FormItem>
                  )}
                />

                <div className="flex justify-end space-x-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsCreateDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button type="submit" disabled={createMutation.isPending}>
                    Create
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Study Interface */}
      {studyMode && filteredCards.length > 0 ? (
        <div className="max-w-2xl mx-auto">
          <Card className="bg-card border-border min-h-[400px]">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Badge variant="outline" className="border-border">
                    {currentCardIndex + 1} of {filteredCards.length}
                  </Badge>
                  <Badge className={getDifficultyColor(currentCard?.difficulty || "")}>
                    {currentCard?.difficulty}
                  </Badge>
                </div>
                <Button
                  variant="outline"
                  onClick={() => setStudyMode(false)}
                  size="sm"
                >
                  Exit Study
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center">
                <h3 className="text-lg font-medium mb-4">
                  {showAnswer ? "Answer" : "Question"}
                </h3>
                <div className="bg-muted rounded-lg p-6 min-h-[200px] flex items-center justify-center">
                  <p className="text-lg leading-relaxed">
                    {showAnswer ? currentCard?.answer : currentCard?.question}
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <Button
                  variant="outline"
                  onClick={prevCard}
                  disabled={filteredCards.length <= 1}
                >
                  <ChevronLeft className="w-4 h-4 mr-2" />
                  Previous
                </Button>

                <Button
                  onClick={() => setShowAnswer(!showAnswer)}
                  className="bg-blue-gradient hover:opacity-90"
                >
                  <RotateCcw className="w-4 h-4 mr-2" />
                  {showAnswer ? "Show Question" : "Show Answer"}
                </Button>

                <Button
                  variant="outline"
                  onClick={nextCard}
                  disabled={filteredCards.length <= 1}
                >
                  Next
                  <ChevronRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      ) : (
        /* Flashcard Grid */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {isLoading ? (
            Array.from({ length: 6 }).map((_, i) => (
              <Card key={i} className="bg-card border-border animate-pulse">
                <CardContent className="p-6">
                  <div className="h-4 bg-muted rounded mb-4"></div>
                  <div className="h-20 bg-muted rounded mb-4"></div>
                  <div className="h-4 bg-muted rounded w-1/2"></div>
                </CardContent>
              </Card>
            ))
          ) : filteredCards.length > 0 ? (
            filteredCards.map((card: Flashcard) => (
              <Card key={card.id} className="bg-card border-border hover:bg-muted/50 transition-colors">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <Badge variant="outline" className="border-border">
                      {card.subject}
                    </Badge>
                    <div className="flex space-x-1">
                      <Button variant="ghost" size="sm">
                        <Edit3 className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteMutation.mutate(card.id)}
                        className="text-red-400 hover:text-red-300"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Question:</p>
                      <p className="text-sm line-clamp-3">{card.question}</p>
                    </div>
                    <div className="flex items-center justify-between">
                      <Badge className={getDifficultyColor(card.difficulty || "")}>
                        {card.difficulty}
                      </Badge>
                      <div className="flex items-center text-xs text-muted-foreground">
                        <Clock className="w-3 h-3 mr-1" />
                        {card.timesReviewed || 0} reviews
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="col-span-full">
              <Card className="bg-card border-border">
                <CardContent className="p-8 text-center">
                  <BookOpen className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">No Flashcards Yet</h3>
                  <p className="text-muted-foreground mb-4">
                    Create your first flashcard to start studying smarter.
                  </p>
                  <Button
                    onClick={() => setIsCreateDialogOpen(true)}
                    className="bg-red-gradient hover:opacity-90"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Create Your First Flashcard
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      )}

      {/* Study Statistics */}
      {filteredCards.length > 0 && !studyMode && (
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle>Study Statistics</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <h3 className="text-2xl font-bold text-blue-400">{filteredCards.length}</h3>
                <p className="text-sm text-muted-foreground">Total Cards</p>
              </div>
              <div className="text-center">
                <h3 className="text-2xl font-bold text-green-400">
                  {filteredCards.filter((c: Flashcard) => c.difficulty === "easy").length}
                </h3>
                <p className="text-sm text-muted-foreground">Easy</p>
              </div>
              <div className="text-center">
                <h3 className="text-2xl font-bold text-yellow-400">
                  {filteredCards.filter((c: Flashcard) => c.difficulty === "intermediate").length}
                </h3>
                <p className="text-sm text-muted-foreground">Intermediate</p>
              </div>
              <div className="text-center">
                <h3 className="text-2xl font-bold text-red-400">
                  {filteredCards.filter((c: Flashcard) => c.difficulty === "hard").length}
                </h3>
                <p className="text-sm text-muted-foreground">Hard</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}