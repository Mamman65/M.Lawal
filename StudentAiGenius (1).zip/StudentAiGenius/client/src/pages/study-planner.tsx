import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Progress } from "@/components/ui/progress";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import { CalendarIcon, Plus, Target, BookOpen, Clock, TrendingUp, Star, CheckCircle2, AlertCircle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertStudyPlanSchema } from "@shared/schema";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import type { StudyPlan } from "@shared/schema";

const MOCK_USER_ID = 1;

interface StudyGoal {
  id: string;
  title: string;
  description: string;
  targetDate: string;
  completed: boolean;
  priority: "low" | "medium" | "high";
}

interface StudySchedule {
  day: string;
  sessions: Array<{
    time: string;
    subject: string;
    duration: number;
    type: "review" | "new" | "practice" | "exam";
  }>;
}

export default function StudyPlanner() {
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<StudyPlan | null>(null);
  const [showCalendar, setShowCalendar] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: studyPlans = [], isLoading } = useQuery({
    queryKey: [`/api/study-plans/user/${MOCK_USER_ID}`],
  });

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/study-plans", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/study-plans/user/${MOCK_USER_ID}`] });
      setIsCreateDialogOpen(false);
      toast({
        title: "Study Plan Created!",
        description: "Your personalized study plan is ready to help you succeed.",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: Partial<StudyPlan> }) => {
      const response = await apiRequest("PATCH", `/api/study-plans/${id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/study-plans/user/${MOCK_USER_ID}`] });
      toast({
        title: "Progress Updated!",
        description: "Your study plan has been updated successfully.",
      });
    },
  });

  const form = useForm({
    resolver: zodResolver(insertStudyPlanSchema),
    defaultValues: {
      title: "",
      subject: "",
      goals: [],
      schedule: [],
      startDate: new Date(),
      endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
    },
  });

  const subjects = [
    { value: "Mathematics", label: "Mathematics" },
    { value: "Physics", label: "Physics" },
    { value: "Chemistry", label: "Chemistry" },
    { value: "Biology", label: "Biology" },
    { value: "Computer Science", label: "Computer Science" },
    { value: "General", label: "General Studies" },
  ];

  const samplePlans = [
    {
      id: 1,
      title: "Calculus Mastery Plan",
      subject: "Mathematics",
      progress: 65,
      startDate: new Date("2024-01-01"),
      endDate: new Date("2024-03-01"),
      isActive: true,
      goals: [
        {
          id: "g1",
          title: "Master Derivatives",
          description: "Complete all derivative rules and applications",
          targetDate: "2024-01-15",
          completed: true,
          priority: "high"
        },
        {
          id: "g2",
          title: "Integration Techniques",
          description: "Learn substitution, parts, and partial fractions",
          targetDate: "2024-02-01",
          completed: true,
          priority: "high"
        },
        {
          id: "g3",
          title: "Applications of Integration",
          description: "Area, volume, and physics applications",
          targetDate: "2024-02-15",
          completed: false,
          priority: "medium"
        },
        {
          id: "g4",
          title: "Final Exam Preparation",
          description: "Review all topics and practice exams",
          targetDate: "2024-03-01",
          completed: false,
          priority: "high"
        }
      ],
      schedule: [
        {
          day: "Monday",
          sessions: [
            { time: "09:00", subject: "Calculus", duration: 90, type: "new" },
            { time: "15:00", subject: "Calculus", duration: 60, type: "practice" }
          ]
        },
        {
          day: "Wednesday",
          sessions: [
            { time: "09:00", subject: "Calculus", duration: 90, type: "review" },
            { time: "14:00", subject: "Calculus", duration: 60, type: "practice" }
          ]
        },
        {
          day: "Friday",
          sessions: [
            { time: "10:00", subject: "Calculus", duration: 120, type: "practice" }
          ]
        }
      ]
    },
    {
      id: 2,
      title: "Physics Fundamentals",
      subject: "Physics",
      progress: 40,
      startDate: new Date("2024-01-15"),
      endDate: new Date("2024-04-15"),
      isActive: true,
      goals: [
        {
          id: "p1",
          title: "Mechanics Basics",
          description: "Motion, forces, and energy concepts",
          targetDate: "2024-02-15",
          completed: true,
          priority: "high"
        },
        {
          id: "p2",
          title: "Thermodynamics",
          description: "Heat, temperature, and energy transfer",
          targetDate: "2024-03-15",
          completed: false,
          priority: "medium"
        },
        {
          id: "p3",
          title: "Electricity & Magnetism",
          description: "Circuits, fields, and electromagnetic waves",
          targetDate: "2024-04-15",
          completed: false,
          priority: "high"
        }
      ]
    }
  ];

  const onSubmit = (data: any) => {
    createMutation.mutate({
      ...data,
      userId: MOCK_USER_ID,
    });
  };

  const updateProgress = (planId: number, newProgress: number) => {
    updateMutation.mutate({
      id: planId,
      updates: { progress: newProgress }
    });
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "text-red-400 bg-red-500/20";
      case "medium": return "text-yellow-400 bg-yellow-500/20";
      case "low": return "text-green-400 bg-green-500/20";
      default: return "text-gray-400 bg-gray-500/20";
    }
  };

  const getSessionTypeColor = (type: string) => {
    switch (type) {
      case "new": return "bg-blue-500/20 text-blue-400";
      case "review": return "bg-green-500/20 text-green-400";
      case "practice": return "bg-orange-500/20 text-orange-400";
      case "exam": return "bg-red-500/20 text-red-400";
      default: return "bg-gray-500/20 text-gray-400";
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold mb-2">
          <span className="text-gradient-red">Study Planner</span>
        </h1>
        <p className="text-muted-foreground">
          Create personalized study plans with goals, schedules, and progress tracking.
        </p>
      </div>

      {/* Action Bar */}
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button
            variant="outline"
            onClick={() => setShowCalendar(!showCalendar)}
            className="border-border"
          >
            <CalendarIcon className="w-4 h-4 mr-2" />
            {showCalendar ? "Hide Calendar" : "Show Calendar"}
          </Button>
        </div>

        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-red-gradient hover:opacity-90">
              <Plus className="w-4 h-4 mr-2" />
              Create Study Plan
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create New Study Plan</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Plan Title</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          placeholder="e.g., SAT Math Preparation"
                          className="bg-muted border-border"
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="subject"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Subject</FormLabel>
                      <FormControl>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <SelectTrigger className="bg-muted border-border">
                            <SelectValue placeholder="Select subject" />
                          </SelectTrigger>
                          <SelectContent>
                            {subjects.map((subject) => (
                              <SelectItem key={subject.value} value={subject.value}>
                                {subject.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </FormControl>
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="startDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Start Date</FormLabel>
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button
                                variant="outline"
                                className={cn(
                                  "w-full pl-3 text-left font-normal bg-muted border-border",
                                  !field.value && "text-muted-foreground"
                                )}
                              >
                                {field.value ? format(field.value, "PPP") : "Pick a date"}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar
                              mode="single"
                              selected={field.value}
                              onSelect={field.onChange}
                              disabled={(date) => date < new Date()}
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="endDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>End Date</FormLabel>
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button
                                variant="outline"
                                className={cn(
                                  "w-full pl-3 text-left font-normal bg-muted border-border",
                                  !field.value && "text-muted-foreground"
                                )}
                              >
                                {field.value ? format(field.value, "PPP") : "Pick a date"}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar
                              mode="single"
                              selected={field.value}
                              onSelect={field.onChange}
                              disabled={(date) => date < new Date()}
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                      </FormItem>
                    )}
                  />
                </div>

                <div className="text-center py-4 text-muted-foreground">
                  <BookOpen className="w-8 h-8 mx-auto mb-2" />
                  <p className="text-sm">Advanced goal and schedule creation coming soon!</p>
                </div>

                <div className="flex justify-end space-x-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsCreateDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button type="submit" disabled={createMutation.isPending}>
                    Create Plan
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Study Plans Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {samplePlans.map((plan) => (
          <Card key={plan.id} className="bg-card border-border">
            <CardHeader>
              <div className="flex items-center justify-between">
                <Badge variant="outline" className="border-border">
                  {plan.subject}
                </Badge>
                <Badge variant={plan.isActive ? "default" : "secondary"}>
                  {plan.isActive ? "Active" : "Completed"}
                </Badge>
              </div>
              <CardTitle className="flex items-center space-x-2">
                <Target className="w-5 h-5 text-blue-400" />
                <span>{plan.title}</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Progress */}
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Progress</span>
                  <span>{plan.progress}%</span>
                </div>
                <Progress value={plan.progress} className="h-2" />
              </div>

              {/* Goals */}
              <div>
                <h4 className="font-medium mb-3 flex items-center">
                  <Star className="w-4 h-4 mr-2 text-yellow-400" />
                  Goals ({plan.goals.filter(g => g.completed).length}/{plan.goals.length})
                </h4>
                <div className="space-y-2 max-h-32 overflow-y-auto">
                  {plan.goals.map((goal) => (
                    <div key={goal.id} className="flex items-center space-x-2 text-sm">
                      {goal.completed ? (
                        <CheckCircle2 className="w-4 h-4 text-green-400" />
                      ) : (
                        <AlertCircle className="w-4 h-4 text-muted-foreground" />
                      )}
                      <span className={goal.completed ? "line-through text-muted-foreground" : ""}>
                        {goal.title}
                      </span>
                      <Badge size="sm" className={getPriorityColor(goal.priority)}>
                        {goal.priority}
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>

              {/* Study Schedule */}
              <div>
                <h4 className="font-medium mb-3 flex items-center">
                  <Clock className="w-4 h-4 mr-2 text-blue-400" />
                  This Week's Schedule
                </h4>
                <div className="space-y-2">
                  {plan.schedule?.slice(0, 2).map((day) => (
                    <div key={day.day} className="text-sm">
                      <div className="font-medium text-muted-foreground mb-1">{day.day}</div>
                      <div className="space-y-1">
                        {day.sessions.map((session, index) => (
                          <div key={index} className="flex items-center justify-between bg-muted rounded px-2 py-1">
                            <span>{session.time} - {session.subject}</span>
                            <div className="flex items-center space-x-2">
                              <Badge size="sm" className={getSessionTypeColor(session.type)}>
                                {session.type}
                              </Badge>
                              <span className="text-xs text-muted-foreground">{session.duration}m</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  onClick={() => setSelectedPlan(plan as any)}
                  className="flex-1"
                >
                  View Details
                </Button>
                <Button
                  onClick={() => updateProgress(plan.id, Math.min(100, plan.progress + 10))}
                  className="bg-green-gradient hover:opacity-90"
                >
                  <TrendingUp className="w-4 h-4 mr-2" />
                  Update Progress
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Calendar View */}
      {showCalendar && (
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle>Study Calendar</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-7 gap-2 text-center mb-4">
              {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((day) => (
                <div key={day} className="font-medium text-muted-foreground p-2">
                  {day}
                </div>
              ))}
            </div>
            <div className="grid grid-cols-7 gap-2">
              {Array.from({ length: 35 }, (_, i) => (
                <div key={i} className="min-h-[80px] p-1 border border-border rounded">
                  <div className="text-xs text-muted-foreground mb-1">
                    {((i % 31) + 1)}
                  </div>
                  {(i + 1) % 7 === 1 && ( // Monday
                    <div className="text-xs bg-blue-500/20 text-blue-400 rounded px-1 py-0.5 mb-1">
                      Calculus 9:00
                    </div>
                  )}
                  {(i + 1) % 7 === 3 && ( // Wednesday
                    <div className="text-xs bg-green-500/20 text-green-400 rounded px-1 py-0.5 mb-1">
                      Physics 10:00
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Study Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="bg-card border-border">
          <CardContent className="p-6 text-center">
            <TrendingUp className="w-8 h-8 text-green-400 mx-auto mb-2" />
            <h3 className="text-2xl font-bold text-green-400">{samplePlans.length}</h3>
            <p className="text-sm text-muted-foreground">Active Plans</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6 text-center">
            <Target className="w-8 h-8 text-blue-400 mx-auto mb-2" />
            <h3 className="text-2xl font-bold text-blue-400">
              {samplePlans.reduce((sum, plan) => sum + plan.goals.filter(g => g.completed).length, 0)}
            </h3>
            <p className="text-sm text-muted-foreground">Goals Completed</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6 text-center">
            <Clock className="w-8 h-8 text-orange-400 mx-auto mb-2" />
            <h3 className="text-2xl font-bold text-orange-400">12.5</h3>
            <p className="text-sm text-muted-foreground">Hours This Week</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6 text-center">
            <Star className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
            <h3 className="text-2xl font-bold text-yellow-400">
              {Math.round(samplePlans.reduce((sum, plan) => sum + plan.progress, 0) / samplePlans.length)}%
            </h3>
            <p className="text-sm text-muted-foreground">Average Progress</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}