import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("first_name"),
  lastName: text("last_name"),
  email: text("email"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const questions = pgTable("questions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  content: text("content").notNull(),
  imageUrl: text("image_url"),
  subject: text("subject").notNull(),
  difficulty: text("difficulty"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const solutions = pgTable("solutions", {
  id: serial("id").primaryKey(),
  questionId: integer("question_id").references(() => questions.id),
  content: text("content").notNull(),
  steps: jsonb("steps"),
  explanation: text("explanation"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const studySessions = pgTable("study_sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  subject: text("subject").notNull(),
  duration: integer("duration"), // in minutes
  questionsAnswered: integer("questions_answered").default(0),
  accuracy: integer("accuracy"), // percentage
  createdAt: timestamp("created_at").defaultNow(),
});

export const formulas = pgTable("formulas", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  formula: text("formula").notNull(),
  subject: text("subject").notNull(),
  description: text("description"),
  examples: jsonb("examples"),
  difficulty: text("difficulty"),
});

export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  name: text("name").notNull(),
  description: text("description"),
  badgeUrl: text("badge_url"),
  earnedAt: timestamp("earned_at").defaultNow(),
});

export const flashcards = pgTable("flashcards", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  subject: text("subject").notNull(),
  question: text("question").notNull(),
  answer: text("answer").notNull(),
  difficulty: text("difficulty"),
  tags: text("tags").array(),
  timesReviewed: integer("times_reviewed").default(0),
  lastReviewed: timestamp("last_reviewed"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const quizzes = pgTable("quizzes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  title: text("title").notNull(),
  subject: text("subject").notNull(),
  questions: jsonb("questions").notNull(),
  timeLimit: integer("time_limit"), // in minutes
  difficulty: text("difficulty"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const quizAttempts = pgTable("quiz_attempts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  quizId: integer("quiz_id").references(() => quizzes.id),
  answers: jsonb("answers").notNull(),
  score: integer("score").notNull(),
  timeSpent: integer("time_spent"), // in seconds
  completedAt: timestamp("completed_at").defaultNow(),
});

export const studyPlans = pgTable("study_plans", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  title: text("title").notNull(),
  subject: text("subject").notNull(),
  goals: jsonb("goals").notNull(),
  schedule: jsonb("schedule").notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  progress: integer("progress").default(0),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  firstName: true,
  lastName: true,
  email: true,
});

export const insertQuestionSchema = createInsertSchema(questions).pick({
  content: true,
  imageUrl: true,
  subject: true,
  difficulty: true,
});

export const insertSolutionSchema = createInsertSchema(solutions).pick({
  questionId: true,
  content: true,
  steps: true,
  explanation: true,
});

export const insertStudySessionSchema = createInsertSchema(studySessions).pick({
  subject: true,
  duration: true,
  questionsAnswered: true,
  accuracy: true,
});

export const insertFormulaSchema = createInsertSchema(formulas).pick({
  name: true,
  formula: true,
  subject: true,
  description: true,
  examples: true,
  difficulty: true,
});

export const insertAchievementSchema = createInsertSchema(achievements).pick({
  name: true,
  description: true,
  badgeUrl: true,
});

export const insertFlashcardSchema = createInsertSchema(flashcards).pick({
  subject: true,
  question: true,
  answer: true,
  difficulty: true,
  tags: true,
});

export const insertQuizSchema = createInsertSchema(quizzes).pick({
  title: true,
  subject: true,
  questions: true,
  timeLimit: true,
  difficulty: true,
});

export const insertQuizAttemptSchema = createInsertSchema(quizAttempts).pick({
  quizId: true,
  answers: true,
  score: true,
  timeSpent: true,
});

export const insertStudyPlanSchema = createInsertSchema(studyPlans).pick({
  title: true,
  subject: true,
  goals: true,
  schedule: true,
  startDate: true,
  endDate: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertQuestion = z.infer<typeof insertQuestionSchema>;
export type Question = typeof questions.$inferSelect;
export type InsertSolution = z.infer<typeof insertSolutionSchema>;
export type Solution = typeof solutions.$inferSelect;
export type InsertStudySession = z.infer<typeof insertStudySessionSchema>;
export type StudySession = typeof studySessions.$inferSelect;
export type InsertFormula = z.infer<typeof insertFormulaSchema>;
export type Formula = typeof formulas.$inferSelect;
export type InsertAchievement = z.infer<typeof insertAchievementSchema>;
export type Achievement = typeof achievements.$inferSelect;
export type InsertFlashcard = z.infer<typeof insertFlashcardSchema>;
export type Flashcard = typeof flashcards.$inferSelect;
export type InsertQuiz = z.infer<typeof insertQuizSchema>;
export type Quiz = typeof quizzes.$inferSelect;
export type InsertQuizAttempt = z.infer<typeof insertQuizAttemptSchema>;
export type QuizAttempt = typeof quizAttempts.$inferSelect;
export type InsertStudyPlan = z.infer<typeof insertStudyPlanSchema>;
export type StudyPlan = typeof studyPlans.$inferSelect;
